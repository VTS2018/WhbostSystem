﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
using System.Collections.Specialized;
using System.Collections;

namespace Whbost.DLL.Site
{
    public class SiteMasterDLL
    {
        /// <summary>
        /// 获取所有的网店模板信息
        /// </summary>
        /// <returns></returns>
        public List<ISite_master_collection> DLL_SiteMaster_list()
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ISite_master_collection> listArr = (from p in db.site_master_collection
                                                      orderby p.sitemaster_createdate descending
                                                      select new ISite_master_collection()
                                                      {
                                                          sitemaster_bateno = p.sitemaster_bateno,
                                                          sitemaster_createdate = p.sitemaster_createdate,
                                                          sitemaster_desc = p.sitemaster_desc,
                                                          sitemaster_id = p.sitemaster_id,
                                                          sitemaster_images = p.sitemaster_images,
                                                          sitemaster_manager = p.sitemaster_manager,
                                                          sitemaster_modifydate = p.sitemaster_modifydate,
                                                          sitemaster_name = p.sitemaster_name,
                                                          sitemaster_no = p.sitemaster_no,
                                                          sitemaster_updateremark = p.sitemaster_updateremark
                                                      }).ToList();
                return listArr;
            }
        }
        /// <summary>
        /// 检查模板编码是否重复
        /// </summary>
        /// <param name="sitemaster_no"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_checkno(string sitemaster_no)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                int check = db.site_master_collection.Where(p => p.sitemaster_no == sitemaster_no).Count();
                return check > 0 ? false : true;
            }
        }
        /// <summary>
        /// 添加新模板
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_add(NameValueCollection form)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                string sitemaster_no = Whbost.Common.systemDefault.ReturnString(form["sitemaster_no"]);
                if (!DLL_SiteMaster_checkno(sitemaster_no))
                    return false;
                else
                {
                    string sitemaster_id = Whbost.Common.systemDefault.GenerateRandom();
                    DateTime dt=System.DateTime.Now.ToUniversalTime();
                    site_master_collection zdata = new site_master_collection()
                    {
                        sitemaster_bateno = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_bateno"]),
                        sitemaster_createdate = dt,
                        sitemaster_desc = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_desc"]),
                        sitemaster_id = sitemaster_id,
                        sitemaster_images = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_images"]),
                        sitemaster_manager = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_manager"]),
                        sitemaster_modifydate = dt,
                        sitemaster_name = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_name"]),
                        sitemaster_no = sitemaster_no,
                        sitemaster_updateremark = Whbost.Common.systemDefault.ReturnString_normal(form["sitemaster_updateremark"]),
                    };
                    db.site_master_collection.InsertOnSubmit(zdata);
                    db.SubmitChanges();
                    return true;
                }
            }
        }
        /// <summary>
        /// 获取模板详细信息
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public ISite_master_collection DLL_SiteMaster_view(string SiteMaster_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                var viewData = (from p in db.site_master_collection
                                where p.sitemaster_id == SiteMaster_id
                                select new ISite_master_collection()
                                {
                                    sitemaster_bateno = p.sitemaster_bateno,
                                    sitemaster_createdate = p.sitemaster_createdate,
                                    sitemaster_desc = p.sitemaster_desc,
                                    sitemaster_id = p.sitemaster_id,
                                    sitemaster_images = p.sitemaster_images,
                                    sitemaster_manager = p.sitemaster_manager,
                                    sitemaster_modifydate = p.sitemaster_modifydate,
                                    sitemaster_name = p.sitemaster_name,
                                    sitemaster_no = p.sitemaster_no,
                                    sitemaster_updateremark = p.sitemaster_updateremark,
                                    sitemaster_createdate_show=Whbost.Common.systemDefault.TimeToLocation(p.sitemaster_createdate.ToString()),
                                    sitemaster_modifydate_show = Whbost.Common.systemDefault.TimeToLocation(p.sitemaster_modifydate.ToString())
                                }).SingleOrDefault();
                return viewData;
            }
        }
        /// <summary>
        /// 更新模板信息
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_modify(NameValueCollection form)
        {
            bool backBool=true;
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                string sitemaster_id = Whbost.Common.systemDefault.ReturnString(form["sitemaster_id"]);
                if (sitemaster_id != null)
                {
                   // ISite_master_collection oneData = DLL_SiteMaster_view(sitemaster_id);
                    var oneData = db.site_master_collection.SingleOrDefault(p => p.sitemaster_id == sitemaster_id);
                    string sitemaster_no = Whbost.Common.systemDefault.ReturnString(form["sitemaster_no"]);
                    if (!Whbost.Common.systemDefault.ReturnString(oneData.sitemaster_no).Equals(sitemaster_no))
                    {
                        //需要检查新更新的sitemaster_no不重复
                        if (!DLL_SiteMaster_checkno(sitemaster_no))
                        {
                            backBool = false;
                        }
                    }
                    //执行更新操作
                    if (!backBool)
                        return backBool;
                    oneData.sitemaster_bateno = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_bateno"], oneData.sitemaster_bateno);
                    oneData.sitemaster_desc = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_desc"], oneData.sitemaster_desc);
                    oneData.sitemaster_images = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_images"], oneData.sitemaster_images);
                    oneData.sitemaster_manager = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_manager"], oneData.sitemaster_manager);
                    oneData.sitemaster_modifydate = System.DateTime.Now.ToUniversalTime();
                    oneData.sitemaster_name = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_name"], oneData.sitemaster_name);
                    oneData.sitemaster_no = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_no"], oneData.sitemaster_no);
                    oneData.sitemaster_updateremark = Whbost.Common.systemDefault.ReturnString_default_normal(form["sitemaster_updateremark"], oneData.sitemaster_updateremark);
                    db.SubmitChanges();
                }
                return backBool;
            }
        }
        /// <summary>
        /// 删除模板
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_del(string SiteMaster_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    IEnumerable<site_master_collection> del = from p in db.site_master_collection
                                                               where p.sitemaster_id == SiteMaster_id
                                                               select p;
                    db.site_master_collection.DeleteAllOnSubmit(del);
                    db.SubmitChanges();
                    return true;
                }
                catch { return false; }
            }
        }
        /// <summary>
        /// 添加模板图片
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <param name="imgValue"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_img_add(string SiteMaster_id, string imgValue)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    var add = db.site_master_collection.SingleOrDefault(p => p.sitemaster_id == SiteMaster_id);
                    if (add != null)
                    {
                        add.sitemaster_images += ((add.sitemaster_images != null && add.sitemaster_images != string.Empty) ? ("|" + imgValue) : imgValue);
                        db.SubmitChanges();
                        return true;
                    }
                    else
                        return false;
                }
                catch { return false; }
            }
        }
        /// <summary>
        /// 返回模板图片地址
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public string DLL_SiteMaster_img_getValue(string SiteMaster_id)
        {
            ISite_master_collection nValue = DLL_SiteMaster_view(SiteMaster_id);
            if (nValue != null)
                return nValue.sitemaster_images != null ? nValue.sitemaster_images : string.Empty;
            else
                return string.Empty;
        }
        /// <summary>
        /// 从数据库删除图片记录
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <param name="delImg"></param>
        /// <returns></returns>
        public bool DLL_SiteMaster_img_del(string SiteMaster_id, string delImg)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    var one = db.site_master_collection.SingleOrDefault(p => p.sitemaster_id == SiteMaster_id);
                    if (one != null)
                    {
                        string imgList = Whbost.Common.systemDefault.ReturnString(one.sitemaster_images);
                        imgList = imgList.Replace(delImg, "").Replace("||", "|");
                        //去掉最后的一个"|"
                        if (imgList != string.Empty)
                        {
                            if (imgList.Substring(imgList.Length - 1, 1) == "|")
                            {
                                imgList = imgList.Substring(0, imgList.Length - 1);
                            }
                            if (imgList.Substring(0, 1) == "|")
                            {
                                imgList = imgList.Substring(1, imgList.Length - 1);
                            }
                        }
                        one.sitemaster_images = imgList;
                        db.SubmitChanges();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch { return false; }
            }
        }
    }
}
