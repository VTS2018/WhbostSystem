﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
using System.Collections.Specialized;
using System.Collections;

namespace Whbost.DLL.Common
{
    public class SysCommonDLL
    {
        /// <summary>
        /// 获取所有的系统分类信息。0|无效分类,1|有效分类,2|所有分类
        /// </summary>
        /// <param name="isValid"></param>
        /// <returns></returns>
        public List<ICategoryInfo> DLL_SysCommon_CategoryInfo(int isValid)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICategoryInfo> list = (from p in db.common_category
                                            where (isValid > 1 ? (1 == 1) : p.category_isvalid == isValid)
                                            orderby p.sortby_int ascending
                                            select new ICategoryInfo()
                                            {
                                                IC = new ICategory()
                                                {
                                                    category_desc = p.category_desc,
                                                    category_field = p.category_field,
                                                    category_id = p.category_id,
                                                    category_isvalid = p.category_isvalid,
                                                    category_name = p.category_name,
                                                    category_pic = p.category_pic,
                                                    sortby_int = p.sortby_int
                                                },
                                                ICValue = (from q in db.common_category_selectvalue
                                                           where q.category_id == p.category_id
                                                           orderby q.sortby_int ascending
                                                           select new ICategory_selectValue()
                                                           {
                                                               category_id = q.category_id,
                                                               category_selectvalue_id = q.category_selectvalue_id,
                                                               category_selectvalue_pic = q.category_selectvalue_pic,
                                                               category_selectvalue_text = q.category_selectvalue_text,
                                                               category_selectvalue_value = q.category_selectvalue_value,
                                                               guid_id = q.guid_id,
                                                               sortby_int = q.sortby_int
                                                           }).ToList()
                                            }).ToList();
                return list;
            }
        }
        public List<ICategory> DLL_SysCommon_Category(int isValid)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICategory> list = (from p in db.common_category
                                        where (isValid > 1 ? (1 == 1) : p.category_isvalid == isValid)
                                        orderby p.sortby_int ascending
                                        select new ICategory()
                                        {

                                            category_desc = p.category_desc,
                                            category_field = p.category_field,
                                            category_id = p.category_id,
                                            category_isvalid = p.category_isvalid,
                                            category_name = p.category_name,
                                            category_pic = p.category_pic,
                                            sortby_int = p.sortby_int
                                        }).ToList();
                return list;

            }
        }
        public List<ICategory_selectValue> DLL_SysCommon_Category_SelectValue(string category_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICategory_selectValue> list = (from q in db.common_category_selectvalue
                                                    where q.category_id == category_id
                                                    orderby q.sortby_int ascending
                                                    select new ICategory_selectValue()
                                                    {
                                                        category_id = q.category_id,
                                                        category_selectvalue_id = q.category_selectvalue_id,
                                                        category_selectvalue_pic = q.category_selectvalue_pic,
                                                        category_selectvalue_text = q.category_selectvalue_text,
                                                        category_selectvalue_value = q.category_selectvalue_value,
                                                        guid_id = q.guid_id,
                                                        sortby_int = q.sortby_int
                                                    }).ToList();
                return list;

            }
        }
        public List<ICategory_selectValue> DLL_SysCommon_Category_SelectValue_byfiled(string category_field)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICategory_selectValue> list = (from p in db.common_category
                                                    from q in db.common_category_selectvalue
                                                    where p.category_field == category_field && q.category_id == p.category_id
                                                    orderby q.sortby_int ascending
                                                    select new ICategory_selectValue()
                                                    {
                                                        category_id = q.category_id,
                                                        category_selectvalue_id = q.category_selectvalue_id,
                                                        category_selectvalue_pic = q.category_selectvalue_pic,
                                                        category_selectvalue_text = q.category_selectvalue_text,
                                                        category_selectvalue_value = q.category_selectvalue_value,
                                                        guid_id = q.guid_id,
                                                        sortby_int = q.sortby_int
                                                    }).ToList();
                return list;

            }
        }
        /// <summary>
        /// 获取单个分类信息(包括选项值)
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public ICategoryInfo DLL_SysCommon_CategoryInfo_one(string category_id)
        {
            ICategoryInfo one = DLL_SysCommon_CategoryInfo(2).SingleOrDefault(p => p.IC.category_id == category_id);
            return one;
        }
        /// <summary>
        /// 获取单个分类信息
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public ICategory DLL_SysCommon_Category_one(string category_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ICategory list = (from p in db.common_category
                                  where p.category_id == category_id
                                  select new ICategory()
                                  {

                                      category_desc = p.category_desc,
                                      category_field = p.category_field,
                                      category_id = p.category_id,
                                      category_isvalid = p.category_isvalid,
                                      category_name = p.category_name,
                                      category_pic = p.category_pic,
                                      sortby_int = p.sortby_int
                                  }).SingleOrDefault();
                return list;

            }
        }

        /// <summary>
        /// 获取单个分类信息
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public ICategory DLL_SysCommon_Category_one_field(string field)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ICategory list = (from p in db.common_category
                                  where p.category_field == field
                                  select new ICategory()
                                  {

                                      category_desc = p.category_desc,
                                      category_field = p.category_field,
                                      category_id = p.category_id,
                                      category_isvalid = p.category_isvalid,
                                      category_name = p.category_name,
                                      category_pic = p.category_pic,
                                      sortby_int = p.sortby_int
                                  }).SingleOrDefault();
                return list;

            }
        }


        /// <summary>
        /// 检查分类编码是否重复
        /// </summary>
        /// <param name="sitemaster_no"></param>
        /// <returns></returns>
        public bool DLL_SysCommon_Category_checkno(string category_field)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                int check = db.common_category.Where(p => p.category_field == category_field).Count();
                return check > 0 ? false : true;
            }
        }
        /// <summary>
        /// 编辑系统分类
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_SysCommon_Category_modify(NameValueCollection form)
        {
            bool backBool = true;
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                string category_id = Whbost.Common.systemDefault.ReturnString(form["category_id"]);
                if (category_id != null)
                {
                    var oneData = db.common_category.SingleOrDefault(p => p.category_id == category_id);
                    string category_field = Whbost.Common.systemDefault.ReturnString(form["category_field"]);
                    if (!Whbost.Common.systemDefault.ReturnString(oneData.category_field).Equals(category_field))
                    {
                        //需要检查新更新的sitemaster_no不重复
                        if (!DLL_SysCommon_Category_checkno(category_field))
                        {
                            backBool = false;
                        }
                    }
                    //执行更新操作
                    if (!backBool)
                        return backBool;
                    oneData.category_desc = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_desc"], oneData.category_desc);
                    oneData.category_field = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_field"], oneData.category_field);
                    oneData.category_isvalid = Whbost.Common.systemDefault.ReturnInt_default(form["category_isvalid"], oneData.category_isvalid);
                    oneData.category_name = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_name"], oneData.category_name);
                    oneData.category_pic = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_pic"], oneData.category_pic);
                    oneData.sortby_int = Whbost.Common.systemDefault.ReturnInt_default(form["sortby_int"], oneData.sortby_int);
                    db.SubmitChanges();
                }
                return backBool;
            }
        }
        /// <summary>
        /// 添加系统分类
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_SysCommon_Category_add(NameValueCollection form)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                string category_field = Whbost.Common.systemDefault.ReturnString(form["category_field"]);
                if (!DLL_SysCommon_Category_checkno(category_field))
                    return false;
                else
                {
                    string category_id = Whbost.Common.systemDefault.GenerateRandom();
                    common_category zdata = new common_category()
                    {
                        category_desc = Whbost.Common.systemDefault.ReturnString_normal(form["category_desc"]),
                        category_field = Whbost.Common.systemDefault.ReturnString_normal(form["category_field"]),
                        category_id = category_id,
                        category_isvalid = Whbost.Common.systemDefault.ReturnInt(form["category_isvalid"]),
                        category_name = Whbost.Common.systemDefault.ReturnString_normal(form["category_name"]),
                        category_pic = Whbost.Common.systemDefault.ReturnString_normal(form["category_pic"]),
                        sortby_int = Whbost.Common.systemDefault.ReturnInt(form["sortby_int"]),
                    };
                    db.common_category.InsertOnSubmit(zdata);
                    db.SubmitChanges();
                    return true;
                }
            }
        }

        /// <summary>
        /// 添加系统分类选项的值列表
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_SysCommon_Category_SelectValue_add(NameValueCollection form)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    string category_selectvalue_id = Whbost.Common.systemDefault.GenerateRandom();
                    common_category_selectvalue zdata = new common_category_selectvalue()
                    {
                        category_id = Whbost.Common.systemDefault.ReturnString_normal(form["category_id"]),
                        category_selectvalue_id = category_selectvalue_id,
                        category_selectvalue_pic = Whbost.Common.systemDefault.ReturnString_normal(form["category_selectvalue_pic"]),
                        category_selectvalue_text = Whbost.Common.systemDefault.ReturnString_normal(form["category_selectvalue_text"]),
                        category_selectvalue_value = Whbost.Common.systemDefault.ReturnString_normal(form["category_selectvalue_value"]),
                        guid_id = Guid.NewGuid(),
                        sortby_int = Whbost.Common.systemDefault.ReturnInt(form["sortby_int"])
                    };
                    db.common_category_selectvalue.InsertOnSubmit(zdata);
                    db.SubmitChanges();
                    return true;
                }
                catch
                { return false; }

            }
        }

        /// <summary>
        /// 获取选择分类的选项值
        /// </summary>
        /// <param name="guid_id"></param>
        /// <returns></returns>
        public ICategory_selectValue DLL_SysCommon_Category_SelectValue_one(string category_selectvalue_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ICategory_selectValue list = (from q in db.common_category_selectvalue
                                              where q.category_selectvalue_id == category_selectvalue_id
                                              select new ICategory_selectValue()
                                              {
                                                  category_id = q.category_id,
                                                  category_selectvalue_id = q.category_selectvalue_id,
                                                  category_selectvalue_pic = q.category_selectvalue_pic,
                                                  category_selectvalue_text = q.category_selectvalue_text,
                                                  category_selectvalue_value = q.category_selectvalue_value,
                                                  guid_id = q.guid_id,
                                                  sortby_int = q.sortby_int
                                              }).SingleOrDefault();
                return list;

            }
        }

        /// <summary>
        /// 删除选择分类的选项值
        /// </summary>
        /// <param name="category_selectvalue_id"></param>
        /// <returns></returns>
        public bool DLL_SysCommon_Category_SelectValue_del(string category_selectvalue_id)
        {
            try
            {
                using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
                {
                    var del = db.common_category_selectvalue.SingleOrDefault(p => p.category_selectvalue_id == category_selectvalue_id);
                    db.common_category_selectvalue.DeleteOnSubmit(del);
                    db.SubmitChanges();
                    return true;
                }
            }
            catch { return false; }
        }
        public bool DLL_SysCommon_Category_SelectValue_modify(NameValueCollection form)
        {
            try
            {
                using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
                {
                    string category_selectvalue_id = Whbost.Common.systemDefault.ReturnString_normal(form["category_selectvalue_id"]);
                    var oneData = db.common_category_selectvalue.SingleOrDefault(p => p.category_selectvalue_id == category_selectvalue_id);
                    if (oneData != null)
                    {
                        oneData.category_selectvalue_pic = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_selectvalue_pic"],oneData.category_selectvalue_pic);
                        oneData.category_selectvalue_text = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_selectvalue_text"],oneData.category_selectvalue_text);
                        oneData.category_selectvalue_value = Whbost.Common.systemDefault.ReturnString_default_normal(form["category_selectvalue_value"], oneData.category_selectvalue_value);
                        oneData.sortby_int = Whbost.Common.systemDefault.ReturnInt_default(form["sortby_int"], oneData.sortby_int);
                    }
                    db.SubmitChanges();
                    return true;
                }
            }
            catch { return false; }
        }

    }
}
