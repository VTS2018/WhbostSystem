﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
namespace Whbost.DLL.SEO
{
    public class LinksDLL
    {
        public List<iLink_collection> Links_DataGrid()
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<iLink_collection> linkList = (from p in db.link_collection
                                                   select new iLink_collection
                                                   {
                                                       link_address = p.link_address,
                                                       link_id = p.link_id
                                                   }).ToList();
                return linkList;
            }
        }
        public List<iLink_collection_page> DLL_Links_DataGrid()
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<iLink_collection_page> linkList = (from p in db.link_collection
                                                        orderby p.link_creatdate descending
                                                   select new iLink_collection_page
                                                   {
                                                       link_address = p.link_address,
                                                       link_creatdate=p.link_creatdate,
                                                       link_pr=p.link_pr,
                                                       author_id=p.author_id,
                                                       link_id = p.link_id
                                                   }).ToList();
                return linkList;
            }
        }
    }
}
