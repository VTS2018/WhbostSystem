﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
using System.Collections.Specialized;
using System.Collections;

namespace Whbost.DLL.File
{
    public class FileDownDLL
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="filedesc"></param>
        /// <param name="filename"></param>
        /// <param name="filefolderpath"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public bool DLL_Filedown_add(IFile_down one)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    file_down add = new file_down()
                    {
                        file_down_id = one.file_down_id,
                        file_create_user_id = one.file_create_user_id,
                        file_createdate = one.file_createdate,
                        file_desc = one.file_desc,
                        file_folderpath = one.file_folderpath,
                        file_id = one.file_id,
                        file_name = one.file_name
                    };
                    db.file_down.InsertOnSubmit(add);
                    db.SubmitChanges();
                    return true;
                }
                catch { return false; }
            }
        }
        /// <summary>
        /// 根据ID显示文件列表
        /// </summary>
        /// <param name="file_id"></param>
        /// <returns></returns>
        public List<IFile_down> DLL_Filedown_list(string file_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<IFile_down> list=(from p in db.file_down
                        where p.file_id == file_id
                        orderby p.file_createdate descending
                        select new IFile_down()
                        {
                            file_create_user_id = p.file_create_user_id,
                            file_createdate = p.file_createdate,
                            file_desc = p.file_desc,
                            file_down_id = p.file_down_id,
                            file_folderpath = p.file_folderpath,
                            file_id = p.file_id,
                            file_name = p.file_name
                        }).ToList();
                return list;
            }
        }
        /// <summary>
        /// 删除文件
        /// </summary>
        /// <param name="file_down_id"></param>
        /// <returns></returns>
        public bool DLL_Filedown_del(string file_down_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                //1.先删除文件
                var one = db.file_down.SingleOrDefault(p => p.file_down_id == new Guid(file_down_id));
                string filePath = "/" + one.file_folderpath + "/" + one.file_id + "/" + one.file_name;
                if (Whbost.Common.systemDefault.DeleteFile(filePath))
                {
                    //2.再从数据库删除数据
                    db.file_down.DeleteOnSubmit(one);
                    db.SubmitChanges();
                    return true;
                    
                }
                else
                    return false;
                
            }
        }
    }
}
