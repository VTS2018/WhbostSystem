﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
using Whbost.Common.AjaxRequest;

namespace Whbost.DLL.User
{
    public class UserDLL
    {

        #region  系统记录用户操作函数
        /// <summary>
        /// 记录用户操作日志
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public bool User_saveOperateLog(ICF_user_operatelog objUser_operate)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    cf_user_operatelog userLog = new cf_user_operatelog()
                    {
                        create_date = objUser_operate.create_date,
                        operate_content = objUser_operate.operate_content,
                        operate_type = objUser_operate.operate_type,
                        user_name = objUser_operate.user_name
                    };
                    db.cf_user_operatelog.InsertOnSubmit(userLog);
                    db.SubmitChanges();
                    return true;
                }
                catch (Exception ex)
                {
                    Whbost.Common.systemDefault.WriteError("User_saveOperateLog", ex.ToString());
                    return false;
                }
            }
        }
        #endregion

        #region  用户登录验证
        /// <summary>
        /// 用户登录操作
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="userPwd"></param>
        /// <returns></returns>
        public bool DLL_User_login(string userName, string userPwd)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                var objUser = db.cf_user.SingleOrDefault(p => p.user_loginname == userName && p.user_loginpwd == userPwd);
                if (objUser != null)
                    return true;
                else
                    return false;
            }
        }
       
        /// <summary>
        /// 记录客户登录日志
        /// </summary>
        /// <param name="objUser_login"></param>
        /// <returns></returns>
        public bool User_saveLoginLog(ICF_user_loginlog objUser_login)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    cf_user_loginlog userLog = new cf_user_loginlog()
                    {
                        login_date = objUser_login.login_date,
                        login_ip = objUser_login.login_ip,
                        login_mac = objUser_login.login_mac,
                        login_otherdesc = objUser_login.login_otherdesc,
                        login_remark = objUser_login.login_remark,
                        login_state = objUser_login.login_state,
                        user_name = objUser_login.user_name
                    };
                    db.cf_user_loginlog.InsertOnSubmit(userLog);
                    db.SubmitChanges();
                    return true;
                }
                catch(Exception ex)
                {
                    Whbost.Common.systemDefault.WriteError("User_saveLoginLog", ex.ToString());
                    return false;
                }
            }
        }
        /// <summary>
        /// 同一操作用户当天最多允许的登录错误次数，默认为5次
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool User_errorLoginCount(string userName)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                //当前时间
                //if (User_state(userName) == true)
                //{
                    DateTime nowDt = System.DateTime.Now.ToUniversalTime().Date;
                    int objUser_loginlog = db.cf_user_loginlog.Where(p => p.user_name == userName && p.login_state == 0 && p.login_date.Date == nowDt).Count();
                    if (objUser_loginlog >5)             
                        return true;
                    else
                        return false;
                //}
                //else
                //    return true;
            }
        }
        /// <summary>
        /// 验证管理员账户是否有效
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public bool User_state(string userName)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                var userData = db.cf_user.SingleOrDefault(p => p.user_loginname == userName);
                if (userData != null && userData.IsVisible > 0)
                    return true;
                else
                    return false;
            }
        }
        /// <summary>
        /// 验证用户的MAC地址
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="mac">MAC的连接符号注意替换为:</param>
        /// <returns></returns>
        public bool User_checkMac(string user_id, string mac)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                int resultInt = db.cf_user_maclist.Where(q=>q.user_id == user_id && q.user_mac == mac).Count();
                if (resultInt > 0)
                    return true;
                else
                    return false;
            }
        }
        /// <summary>
        /// 登录成功后,根据用户名获取客户信息
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public ICF_user User_getAccount(string userName)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                return (from p in db.cf_user
                        where p.user_loginname == userName
                        select new ICF_user()
                        {
                            create_data = p.create_date,
                            create_user_id = p.create_user_id,
                            IsVisible = p.IsVisible,
                            IsVisible_mac = p.IsVisible_mac,
                            modify_data = p.mdoify_date,
                            modify_user_id = p.modify_user_id,
                            RecordStatus = p.RecordStatus,
                            user_id = p.user_id,
                            user_loginname = p.user_loginname
                        }).SingleOrDefault();
            }
        }
        #endregion

        #region 用户便捷方式操作
        public List<ICF_user_favorite> DLL_User_favorite_list(string user_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICF_user_favorite> arrList = (from p in db.cf_user_favorite
                                                   from q in db.sys_menu
                                                   where p.user_id == user_id && p.menu_id == q.menu_id
                                                   orderby p.create_date ascending
                                                   select new ICF_user_favorite()
                                                   {
                                                       create_date = p.create_date,
                                                       favorite_content = p.favorite_content,
                                                       int_random_id = p.int_random_id,
                                                       menu_icon = q.menu_icon,
                                                       menu_id = p.menu_id,
                                                       menu_name = q.menu_name,
                                                       menu_url = q.menu_url,
                                                       user_id = user_id,
                                                       favorite_id=p.favorite_id,
                                                       menu_no=q.menu_no
                                                      
                                                   }).ToList();
                return arrList;
            }
        }
        public bool DLL_User_favorite_modify(ICF_user_favorite uf,string user_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                bool backBool = true;
                try
                {
                    
                    if (uf.favorite_id != null && uf.favorite_id != string.Empty)
                    {
                        //删除便捷方式
                        var del = db.cf_user_favorite.SingleOrDefault(p => p.user_id == user_id && p.favorite_id == uf.favorite_id);
                        db.cf_user_favorite.DeleteOnSubmit(del);
                        db.SubmitChanges();
                    }
                    else
                    {
                        string newID = Whbost.Common.systemDefault.GenerateRandom();
                        var checkInfo = db.cf_user_favorite.SingleOrDefault(p => p.user_id == user_id && p.menu_id == uf.menu_id);

                        if (checkInfo != null)
                        {
                            //便捷方式已存在
                            checkInfo.favorite_content = uf.favorite_content;
                            db.SubmitChanges();

                        }
                        else
                        {
                            //添加便捷方式
                            cf_user_favorite add = new cf_user_favorite()
                            {
                                create_date = uf.create_date,
                                favorite_content = uf.favorite_content,
                                favorite_id = newID,
                                menu_id = uf.menu_id,
                                user_id = user_id
                            };
                            db.cf_user_favorite.InsertOnSubmit(add);
                            db.SubmitChanges();
                        }
                    }
                }
                catch { backBool = false; }
                return backBool;
            }
        }
        #endregion
    }
}
