﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using Whbost.Intrefaces;
using System.Collections.Specialized;
using System.Collections;
//using Whbost.Common.AjaxRequest;

namespace Whbost.DLL.User
{
    /// <summary>
    /// 系统菜单模式
    /// </summary>
    public class UserMenuDLL
    {
        #region 系统菜单
        /// <summary>
        /// 获取用户菜单
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public List<ISys_Menu_User> DLL_UserMenu_list(string user_id,int isShow)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                //1.获取系统所有菜单信息
                List<ISys_Menu_User> menuList = DLL_System_menu(isShow);
                /////////设置管理员特列///////////////
                string suser_id = "8888888888";
                //////////////////////////////////////
                //2.验证用户角色权限
                ICF_user_role userRole = DLL_User_role(user_id);
                if (userRole != null && userRole.user_default_right == 1 && user_id != suser_id)
                {
                    //用户为角色默认权限
                    List<ICF_user_menu_default> userMdefault = DLL_User_menuDefault(userRole.role_id);
                    menuList = (from p in menuList
                                from q in userMdefault
                                where p.menu_id == q.menu_id
                                select p).ToList();
                }
                else if (userRole != null && userRole.user_default_right == 0 && user_id != suser_id)
                {
                    //用户为角色自定义权限
                    List<ICF_user_menu_custom> userMcustom = DLL_User_menuCustom(user_id);
                    menuList = (from p in menuList
                                from q in userMcustom
                                where p.menu_id == q.menu_id
                                select p).ToList();
                }
                else if (user_id != suser_id)
                {
                    menuList = null;
                }
                return menuList;
            }
        }
        /// <summary>
        /// 获取系统所有显示菜单列表.【0,表示不在菜单列表中显示的页面|1,表示在菜单列表中显示的页面|2,表示显示全部菜单页面|3,表示只显示全部的主菜单
        /// </summary>
        /// <returns></returns>
        public List<ISys_Menu_User> DLL_System_menu(int isShow)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ISys_Menu_User> menuList = (from p in db.sys_menu
                                                 where p.menu_parent_no == null && (isShow>1?(1==1):(p.menu_show == isShow))
                                                 orderby p.menu_sort ascending
                                                 select new ISys_Menu_User()
                                                 {
                                                     icon = p.menu_icon,
                                                     id = p.menu_id,
                                                     text = p.menu_name,
                                                     children = (isShow<3)?(from q in db.sys_menu
                                                                 where q.menu_parent_no == p.menu_no && (isShow > 1 ? (1 == 1) : (q.menu_show == isShow))
                                                                 orderby q.menu_sort ascending
                                                                 select new ISys_Menu_User_Children()
                                                                 {
                                                                     icon = q.menu_icon,
                                                                     id = q.menu_id,
                                                                     text = q.menu_name,
                                                                     menu_icon = q.menu_icon,
                                                                     menu_id = q.menu_id,
                                                                     menu_name = q.menu_name,
                                                                     menu_no = q.menu_no,
                                                                     menu_parent_no = q.menu_parent_no,
                                                                     menu_url = q.menu_url,
                                                                     menu_sort=q.menu_sort,
                                                                     menu_desc=q.menu_desc,
                                                                     IsVisible=q.IsVisible,
                                                                     menu_show=q.menu_show
                                                                 }).ToList():null,
                                                     menu_icon = p.menu_icon,
                                                     menu_id = p.menu_id,
                                                     menu_name = p.menu_name,
                                                     menu_no = p.menu_no,
                                                     menu_parent_no = p.menu_parent_no,
                                                     menu_url = p.menu_url,
                                                     menu_sort=p.menu_sort,
                                                     menu_desc=p.menu_desc,
                                                     IsVisible=p.IsVisible,
                                                     menu_show=p.menu_show
                                                 }).ToList();
                return menuList;
            }
        }
        /// <summary>
        /// 获取子菜单
        /// </summary>
        /// <param name="menu_no"></param>
        /// <returns></returns>
        public List<ISys_Menu_User> DLL_System_menu_next(string menu_no)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ISys_Menu_User> menuList = (from p in db.sys_menu
                                                 where p.menu_parent_no == menu_no
                                                 orderby p.menu_sort ascending
                                                 select new ISys_Menu_User()
                                                 {
                                                     icon = p.menu_icon,
                                                     id = p.menu_id,
                                                     text = p.menu_name,
                                                     menu_icon = p.menu_icon,
                                                     menu_id = p.menu_id,
                                                     menu_name = p.menu_name,
                                                     menu_no = p.menu_no,
                                                     menu_parent_no = p.menu_parent_no,
                                                     menu_url = p.menu_url,
                                                     menu_sort = p.menu_sort,
                                                     menu_desc = p.menu_desc,
                                                     IsVisible = p.IsVisible,
                                                     menu_show = p.menu_show
                                                 }).ToList();
                return menuList;
            }
        }
        /// <summary>
        /// 获取用户角色信息
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public ICF_user_role DLL_User_role(string user_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ICF_user_role userRole = (from p in db.cf_user_role
                                          where p.user_id == user_id
                                          select new ICF_user_role()
                                          {
                                              role_id = p.role_id,
                                              create_date = p.create_date,
                                              create_user_id = p.create_user_id,
                                              modfiy_user_id = p.modify_user_id,
                                              modify_date = p.modify_date,
                                              RecordStatus = p.RecordStatus,
                                              user_id = p.user_id,
                                              user_default_right=p.user_default_right
                                          }).SingleOrDefault();
                return userRole;
            }
        }
        /// <summary>
        /// 获取用户角色的菜单信息
        /// </summary>
        /// <param name="role_id"></param>
        /// <returns></returns>
        public List<ICF_user_menu_default> DLL_User_menuDefault(string role_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO()) 
            {
                List<ICF_user_menu_default> userMdefault = (from p in db.cf_user_menu_default
                                                      where p.role_id == role_id
                                                      select new ICF_user_menu_default()
                                                      {
                                                          int_random_id = p.int_random_id,
                                                          menu_id = p.menu_id,
                                                          role_id = p.role_id
                                                      }).ToList();
                return userMdefault;
            }
        }
        /// <summary>
        /// 获取用户的自定义菜单信息
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public List<ICF_user_menu_custom> DLL_User_menuCustom(string user_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ICF_user_menu_custom> userMcustom = (from p in db.cf_user_menu_custom
                                                           where p.user_id == user_id
                                                           select new ICF_user_menu_custom()
                                                            {
                                                                int_random_id = p.int_random_id,
                                                                menu_id = p.menu_id,
                                                                user_id = p.user_id
                                                            }).ToList();
                return userMcustom;
            }
        }
        /// <summary>
        /// 获取单个菜单详细信息
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public ISys_Menu DLL_Sysmenu_one(string menu_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ISys_Menu one = (from p in db.sys_menu
                                 where p.menu_id == menu_id
                                 select new ISys_Menu()
                                 {
                                     IsLeaf = p.IsLeaf,
                                     IsVisible = p.IsVisible,
                                     menu_desc = p.menu_desc,
                                     menu_icon = p.menu_icon,
                                     menu_id = p.menu_id,
                                     menu_name = p.menu_name,
                                     menu_no = p.menu_no,
                                     menu_parent_no = p.menu_parent_no,
                                     menu_show = p.menu_show,
                                     menu_sort = p.menu_sort,
                                     menu_url = p.menu_url
                                 }).SingleOrDefault();
                return one;
            }
        }
        /// <summary>
        /// 获取单个菜单详细信息
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public ISys_Menu DLL_Sysmenu_one_bymenu_no_select(string menu_no)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                ISys_Menu one = (from p in db.sys_menu
                                 where p.menu_no == menu_no
                                 select new ISys_Menu()
                                 {
                                     //IsLeaf = p.IsLeaf,
                                     //IsVisible = p.IsVisible,
                                     //menu_desc = p.menu_desc,
                                     //menu_icon = p.menu_icon,
                                     //menu_id = p.menu_id,
                                     //menu_name = p.menu_name,
                                     //menu_no = p.menu_no,
                                     menu_parent_no = p.menu_no,
                                     //menu_show = p.menu_show,
                                     //menu_sort = p.menu_sort,
                                     //menu_url = p.menu_url
                                 }).SingleOrDefault();
                return one;
            }
        }
        /// <summary>
        /// 删除主菜单,同时会删除所有子菜单
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public bool DLL_Sysmenu_del(string menu_id) 
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    var sl = db.sys_menu.SingleOrDefault(p => p.menu_id == menu_id);
                    if (sl != null && sl.menu_parent_no == null)
                    {
                        //说明删除的是主菜单，需要先删除该菜单下所有子菜单
                        IEnumerable<sys_menu> del_1 = from q in db.sys_menu
                                                    where q.menu_parent_no == sl.menu_no
                                                    select q;
                        db.sys_menu.DeleteAllOnSubmit(del_1);
                    }
                    IEnumerable<sys_menu> del = from p in db.sys_menu
                                                where p.menu_id == menu_id
                                                select p;
                    db.sys_menu.DeleteAllOnSubmit(del);
                    db.SubmitChanges();
                    return true;
                }
                catch { return false; }
            }
        }
        /// <summary>
        /// 添加新的主菜单
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool DLL_Sysmenu_add(NameValueCollection form)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                string menu_no = Whbost.Common.systemDefault.ReturnString(form["menu_no"]);
                if (!DLL_Sysmenu_checkno(menu_no))
                    return false;
                else
                {
                    string menu_id = Whbost.Common.systemDefault.GenerateRandom();
                    sys_menu sys = new sys_menu()
                    {
                        menu_id = menu_id,
                        menu_desc = Whbost.Common.systemDefault.ReturnString_normal(form["menu_desc"]),
                        menu_icon = Whbost.Common.systemDefault.ReturnString_normal(form["menu_icon"]),
                        menu_name = Whbost.Common.systemDefault.ReturnString_normal(form["menu_name"]),
                        menu_no = Whbost.Common.systemDefault.ReturnString_normal(form["menu_no"]),
                        menu_parent_no = Whbost.Common.systemDefault.ReturnString_normal(form["menu_parent_no"]),
                        IsVisible = Whbost.Common.systemDefault.ReturnInt_default(form["IsVisible"], 1),
                        IsLeaf = Whbost.Common.systemDefault.ReturnInt_default(form["IsLeaf"], 0),
                        menu_show = Whbost.Common.systemDefault.ReturnInt_default(form["menu_show"], 1),
                        menu_sort = Whbost.Common.systemDefault.ReturnInt_default(form["menu_sort"], 0),
                        menu_url = Whbost.Common.systemDefault.ReturnString_normal(form["menu_url"])
                    };
                    db.sys_menu.InsertOnSubmit(sys);
                    db.SubmitChanges();
                    return true;
                }
            }
        }
        /// <summary>
        /// 检测菜单编码的唯一性
        /// </summary>
        /// <param name="menu_no"></param>
        /// <returns></returns>
        public bool DLL_Sysmenu_checkno(string menu_no)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                int check = db.sys_menu.Where(p => p.menu_no == menu_no).Count();
                return check>0?false:true;
            }
        }
        /// <summary>
        /// 检测菜单编码+菜单ID的唯一性
        /// </summary>
        /// <param name="menu_no"></param>
        /// <returns></returns>
        public bool DLL_Sysmenu_check(string menu_no,string menu_id)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                int check = db.sys_menu.Where(p => p.menu_no == menu_no&&p.menu_id==menu_id).Count();
                return check > 0 ? true : false;
            }
        }
         public bool DLL_Sysmenu_modify(NameValueCollection form)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                try
                {
                    string menu_id = Whbost.Common.systemDefault.ReturnString(form["menu_id"]);
                    string menu_no = Whbost.Common.systemDefault.ReturnString_normal(form["menu_no"]);
                    if (!DLL_Sysmenu_check(menu_no,menu_id))
                    {
                        if (!DLL_Sysmenu_checkno(menu_no))
                            return false;
                    }

                    //1.将所有该主菜单下面的2级菜单的parent进行更新
                    var slbatch = from p in db.sys_menu
                                  from q in db.sys_menu
                                  where p.menu_parent_no == q.menu_no && q.menu_id == menu_id
                                  select p;
                    if (slbatch != null)
                    {
                        foreach (var str in slbatch)
                        {
                            str.menu_parent_no = menu_no;
                        }
                    }
                    //2.更新菜单信息
                    var sl = db.sys_menu.SingleOrDefault(p => p.menu_id == menu_id);
                    if (sl != null)
                    {
                        sl.menu_desc = Whbost.Common.systemDefault.ReturnString_default_normal(form["menu_desc"],sl.menu_desc);
                        sl.menu_icon = Whbost.Common.systemDefault.ReturnString_default(form["menu_icon"],sl.menu_icon);
                        sl.menu_name = Whbost.Common.systemDefault.ReturnString_default_normal(form["menu_name"], sl.menu_name);
                        sl.menu_no = Whbost.Common.systemDefault.ReturnString_default_normal(form["menu_no"], menu_no);
                        sl.menu_parent_no = Whbost.Common.systemDefault.ReturnString_default_normal(form["menu_parent_no"], sl.menu_parent_no);
                        sl.IsVisible = Whbost.Common.systemDefault.ReturnInt_default(form["IsVisible"], 1);
                        sl.IsLeaf = Whbost.Common.systemDefault.ReturnInt_default(form["IsLeaf"], 0);
                        sl.menu_show = Whbost.Common.systemDefault.ReturnInt_default(form["menu_show"], 1);
                        sl.menu_sort = Whbost.Common.systemDefault.ReturnInt_default(form["menu_sort"], 0);
                        sl.menu_url = Whbost.Common.systemDefault.ReturnString_default(form["menu_url"],sl.menu_url);

                        ///开始执行
                        db.SubmitChanges();
                    }
                    return true;
                }
                catch { return false; }
            }
        }
        #endregion

        #region 系统按钮
        public List<ISys_button> DLL_UserBtn_menuNo(string user_id,string menu_no)
        {
            using (WhbostDataBaseContext_SEO db = new WhbostDataBaseContext_SEO())
            {
                List<ISys_button> list = (from p in db.sys_button
                                          select new ISys_button()
                                          {
                                              btn_class = p.btn_class,
                                              btn_id = p.btn_id,
                                              btn_name = p.btn_name,
                                              btn_no = p.btn_no,
                                              btn_icon=p.btn_icon,
                                              btn_script = p.btn_script,
                                              InitStatus = p.InitStatus,
                                              menu_no = p.menu_no,
                                              SeqNo = p.SeqNo
                                          }).ToList();
                return list;
            }
        }
        #endregion 
    }
}
