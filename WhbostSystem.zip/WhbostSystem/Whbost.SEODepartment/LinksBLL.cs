﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.DataBase;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common;
using Whbost.DLL;
namespace Whbost.BLL.SeoDept
{
    public class LinksBLL
    {
        private int arrTotal = 0; //Jhon格式中返回记录总数
        private string jsonObject = string.Empty; //Json数据集格式
        private string json = string.Empty; //Json返回结果
       /// <summary>
       /// 外链数据集合
       /// </summary>
       /// <param name="sortname"></param>
       /// <param name="sortorder"></param>
       /// <param name="where"></param>
       /// <param name="_pagenumber"></param>
       /// <param name="_pagesize"></param>
       /// <returns></returns>
        public string Links_Json_DataGird(string sortname, string sortorder, string where, int _pagenumber, int _pagesize)
        {
                DLL.SEO.LinksDLL db = new Whbost.DLL.SEO.LinksDLL();
                iLink_collection ilink_collection = new iLink_collection();

                List<iLink_collection> linksList = db.Links_DataGrid();
                //对List数据进行搜索

                // 获取数据记总数
                arrTotal = linksList.ToArray().Length;
                //对LIST数据进行排序
                Whbost.Common.sortby.Reverser<iLink_collection> reverser = new Whbost.Common.sortby.Reverser<iLink_collection>(ilink_collection.GetType(), sortname, sortorder == "desc" ? (Whbost.Common.sortby.ReverserInfo.Direction.DESC) : Whbost.Common.sortby.ReverserInfo.Direction.ASC);
                linksList.Sort(reverser);
                //对LIST数据进行分页
            if(_pagenumber>0&&_pagesize>0)
            {
                linksList = linksList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
                jsonObject = Whbost.Common.systemDefault.ListToJson(linksList);
                json = @"{""Rows"":" + jsonObject + @",""Total"":""" + arrTotal + @"""}";
                return json;
            }
        
    }
}
