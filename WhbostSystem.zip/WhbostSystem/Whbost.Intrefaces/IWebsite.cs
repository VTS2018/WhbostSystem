﻿using System;
using System.Collections.Generic;

namespace Whbost.Intrefaces
{
    /// <summary>
    /// 网店的模板管理
    /// </summary>
    public class ISite_master_collection
    {
        public string sitemaster_id { get; set; }
        public string sitemaster_no { get; set; }
        public string sitemaster_name { get; set; }
        public string sitemaster_desc { get; set; }
        public string sitemaster_images { get; set; }
        public DateTime sitemaster_createdate { get; set; }
        public string sitemaster_createdate_show { get; set; }
        public DateTime sitemaster_modifydate { get; set; }
        public string sitemaster_modifydate_show { get; set; }
        public string sitemaster_bateno { get; set; }
        public string sitemaster_manager { get; set; }
        public string sitemaster_updateremark { get; set; }
    }
}
