﻿using System;
using System.Collections.Generic;
namespace Whbost.Intrefaces
{
    ////////////////////////////菜单部分为：(菜单部分)页面权限+角色权限+按钮权限组成/////////////////////////////////////
    #region  系统菜单
    /// <summary>
    /// 系统菜单全部信息
    /// </summary>
    public class ISys_Menu
    {
        public string menu_id { get; set; }
        public string menu_no { get; set; }
        public string menu_parent_no { get; set; }
        public string menu_name { get; set; }
        public string menu_url { get; set; }
        public string menu_icon { get; set; }
        public int IsVisible { get; set; }
        public int IsLeaf { get; set; }
        public int menu_sort { get; set; }
        public string menu_desc { get; set; }
        public int menu_show { get; set; }
    }
    /// <summary>
    /// json格式所需要的系统显示菜单子菜单
    /// </summary>
    public class ISys_Menu_User_Children
    {
        public string icon { get; set; }
        public string id { get; set; }
        public string text { get; set; }
        public string menu_id { get; set; }
        public string menu_no { get; set; }
        public string menu_parent_no { get; set; }
        public string menu_name { get; set; }
        public string menu_desc { get; set; }
        public string menu_url { get; set; }
        public string menu_icon { get; set; }
        public int menu_sort { get; set; }
        public int menu_show { get; set; }
        public int IsVisible { get; set; }
    }
    /// <summary>
    /// json格式所需要的系统显示菜单集合
    /// </summary>
    public class ISys_Menu_User
    {
        public string icon { get; set; }
        public string id { get; set; }
        public List<ISys_Menu_User_Children> children { get; set; }
        public string text { get; set; }
        public string menu_id { get; set; }
        public string menu_no { get; set; }
        public string menu_parent_no { get; set; }
        public string menu_name { get; set; }
        public string menu_desc { get; set; }
        public string menu_url { get; set; }
        public string menu_icon { get; set; }
        public int menu_sort { get; set; }
        public int menu_show { get; set; }
        public int IsVisible { get; set; }
    }
#endregion

    #region 系统角色
    /// <summary>
    /// 系统角色定义
    /// </summary>
    public class ICF_role
    {
        public string role_id { get; set; }
        public string role_name { get; set; }
        public string role_desc { get; set; }
        public int role_level { get; set; }
        public string create_user_id { get; set; }
        public DateTime create_date { get; set; }
        public string modfiy_user_id { get; set; }
        public DateTime modify_date { get; set; }
        public string RecordStatus { get; set; }
    }
    /// <summary>
    /// 用户所属系统角色
    /// </summary>
    public class ICF_user_role
    {
        public string user_id { get; set; }
        public string role_id { get; set; }
        public string create_user_id { get; set; }
        public DateTime create_date { get; set; }
        public string modfiy_user_id { get; set; }
        public DateTime modify_date { get; set; }
        public string RecordStatus { get; set; }
        public int user_default_right { get; set; }
    }
    /// <summary>
    /// 系统角色默认菜单
    /// </summary>
    public class ICF_user_menu_default
    {
        public int int_random_id { get; set; }
        public string role_id { get; set; }
        public string menu_id { get; set; }
    }
    /// <summary>
    /// 系统角色自定义菜单
    /// </summary>
    public class ICF_user_menu_custom
    {
        public int int_random_id { get; set; }
        public string user_id { get; set; }
        public string menu_id { get; set; }
    }

#endregion

    #region 系统按钮
    public class ISys_button
    {
        public string btn_id { get; set; }
        public string btn_name { get; set; }
        public string btn_no{get;set;}
        public string btn_class{get;set;}
        public string btn_icon { get; set; }
        public string btn_script{get;set;}
        public string menu_no { get; set; }
        public string InitStatus { get; set; }
        public int SeqNo { get; set; }
    }
    #endregion
}
