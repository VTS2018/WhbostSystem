﻿using System;
using System.Collections.Generic;


namespace Whbost.Intrefaces
{
    /// <summary>
    /// 定义用户的登录账号密码
    /// </summary>
    public class ICF_user
    {
        public string user_id { get; set; }
        public string user_loginname { get; set; }
        public string user_loginpwd { get; set; }
        public int IsVisible { get; set; }
        public string create_user_id { get; set; }
        public DateTime create_data { get; set; }
        public string modify_user_id { get; set; }
        public DateTime modify_data { get; set; }
        public string RecordStatus { get; set; }
        public int IsVisible_mac { get; set; }
    }
    /// <summary>
    /// 重定义客户的按钮权限
    /// </summary>
    public class ICF_user_button_custom
    {
        public int int_random_id { get; set; }
        public string user_id { get; set; }
        public string btn_id { get; set; }
    }
    /// <summary>
    /// 设定角色默认按钮权限
    /// </summary>
    public class ICF_user_button_default
    {
        public int int_random_id { get; set; }
        public string role_id { get; set; }
        public string btn_id { get; set; }
    }
    /// <summary>
    /// 用户常用联系信息
    /// </summary>
    public class ICF_user_info
    {
        public string user_id { get; set; }
        public string dept_id { get; set; }
        public string user_realname { get; set; }
        public string user_nickname { get; set; }
        public string user_sex { get; set; }
        public string user_phone { get; set; }
        public string user_qq { get; set; }
        public string user_msn { get; set; }
        public string user_email { get; set; }
        public string user_cardid { get; set; }
        public string user_address { get; set; }
        public string RecordStatus { get; set; }
    }
    /// <summary>
    /// 客户登录日志
    /// </summary>
    public class ICF_user_loginlog
    {
        public int int_random_id { get; set; }
        public string user_name { get; set; }
        public string login_ip { get; set; }
        public string login_mac { get; set; }
        public string login_otherdesc { get; set; }
        public DateTime login_date { get; set; }
        public string login_remark { get; set; }
        public int login_state { get; set; }
    }
    /// <summary>
    /// 客户授权MAC地址列表
    /// </summary>
    public class ICF_user_maclist
    {
        public int int_random_id { get; set; }
        public string user_id { get; set; }
        public string user_mac { get; set; }
        public string mac_remark { get; set; }
        public string create_user_id { get; set; }
        public DateTime create_date { get; set; }
    }
    /// <summary>
    /// 用户系统操作日子
    /// </summary>
    public class ICF_user_operatelog 
    {
        public int int_random_id { get; set; }
        public string user_name { get; set; }
        public string operate_type { get; set; }
        public string operate_content{get;set;}
        public DateTime create_date{get;set;}
    }
    /// <summary>
    /// 用户页面快捷方式
    /// </summary>
    public class ICF_user_favorite
    {
        public int int_random_id { get; set; }
        public string favorite_id { get; set; }
        public string user_id { get; set; }
        public string menu_id { get; set; }
        public string menu_no { get; set; }
        public string menu_name { get; set; }
        public string menu_url { get; set; }
        public string menu_icon { get; set; }
        public string favorite_content { get; set; }
        public DateTime create_date { get; set; }
    }
}
