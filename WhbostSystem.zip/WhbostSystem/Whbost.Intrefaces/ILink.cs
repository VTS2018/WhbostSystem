﻿using System;
using System.Collections.Generic;

namespace Whbost.Intrefaces
{
    public class iLink_collection
    {
        public int int_random_id { get; set; }
        public string link_id { get; set; }
        public string link_address { get; set; }
        public DateTime link_creatdate { get; set; }
        public int link_pr { get; set; }
        public string author_id { get; set; }
    }
    public class iLink_collection_page
    {
        public string link_id { get; set; }
        public string link_address { get; set; }
        public DateTime link_creatdate { get; set; }
        public int link_pr { get; set; }
        public int link_loginstate { get; set; }
        public string author_id { get; set; }
        public string author_name { get; set; }
    }
}
