﻿using System;
using System.Collections.Generic;

namespace Whbost.Intrefaces
{
    /// <summary>
    /// 用来返回SELECT的JSON格式
    /// </summary>
    public class IAjaxSelect
    {
        public string id { get; set; }
        public string value { get; set; }
        public string text { get; set; }
    }
    /// <summary>
    /// 文件下载管理
    /// </summary>
    public class IFile_down
    {
        public Guid file_down_id { get; set; }
        public string file_id { get; set; }
        public string file_desc { get; set; }//文件的中文名称
        public string file_name { get; set; }
        public string file_folderpath { get; set; }
        public DateTime file_createdate { get; set; }
        public string file_create_user_id { get; set; }
    }
    /// <summary>
    /// 系统各种分类
    /// </summary>
    public class ICategory
    {
        public string category_id { get; set; }
        public string category_name { get; set; }
        public string category_field { get; set; }
        public string category_desc { get; set; }
        public string category_pic { get; set; }
        public int sortby_int { get; set; }
        public int category_isvalid { get; set; }
    }
    /// <summary>
    /// 系统分类的选项值
    /// </summary>
    public class ICategory_selectValue
    {
        public Guid guid_id { get; set; }
        public string category_id { get; set; }
        public string category_selectvalue_id { get; set; }
        public string category_selectvalue_text { get; set; }
        public string category_selectvalue_value { get; set; }
        public string category_selectvalue_pic { get; set; }
        public int sortby_int { get; set; }
    }
    /// <summary>
    /// 系统分类的集合
    /// </summary>
    public class ICategoryInfo
    {
        public ICategory IC { get; set; }
        public List<ICategory_selectValue> ICValue { get; set; }
    }
    /// <summary>
    /// 定义检索规则
    /// </summary>
    public class FilterRule
    {
        public string field { get; set; }
        public object value { get; set; }
        public string op { get; set; }
        public string type { get; set; }
    }
    /// <summary>
    /// 对应前台 ligerFilter 的检索规则数据
    /// </summary>
    public class FilterGroup
    {
        public IList<FilterRule> rules { get; set; }
        public string op { get; set; }
        public IList<FilterGroup> groups { get; set; }
    }
}
