﻿using System;
using System.Configuration;
using System.IO;

namespace Whbost.DataBase
{
    public class WhbostDataBaseContext_SEO : WhbostDataBase_SEODataContext, IDisposable
    {
        private StreamWriter sw;
        private bool isTrackLog = bool.Parse(ConfigurationManager.AppSettings["TrackLinqLog"]);

        public WhbostDataBaseContext_SEO()
            : base(ConfigurationManager.ConnectionStrings["SNDataConnectionString"].ConnectionString)
        {
            if (isTrackLog)
            {
                Random rd = new Random();
                sw = new StreamWriter((ConfigurationManager.AppSettings["ServerPath"] + ConfigurationManager.AppSettings["LinqLogPath"] + "\\" + DateTime.Now.ToString("yyyyMMddhhmmss") + rd.Next(100, 999).ToString() + ".txt"), true);
                this.Log = sw;
            }

            //this.Log = new DebuggerWriter();
        }
        #region IDisposable Members

        void IDisposable.Dispose()
        {
            if (isTrackLog)
            {
                sw.Close();
            }
            this.Dispose();
        }

        #endregion
    }
}
