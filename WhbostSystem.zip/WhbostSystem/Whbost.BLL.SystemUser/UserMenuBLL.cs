﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common.AjaxRequest;

namespace Whbost.BLL.SystemUser
{
    public class UserMenuBLL
    {
        public string json = string.Empty;
        public int total = 0;
        DLL.User.UserMenuDLL db = new Whbost.DLL.User.UserMenuDLL();
        /// <summary>
        /// 获取用户系统菜单,树形{0,表示不在菜单列表中显示的页面|1,表示在菜单列表中显示的页面|2,表示显示全部菜单页面|3,表示只显示全部的主菜单}
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="isShow"></param>
        /// <returns></returns>
        public string UserMenu_list_json(string user_id,int isShow)
        {
            
            List<ISys_Menu_User> menuList = db.DLL_UserMenu_list(user_id,isShow);
           // total = menuList.ToArray().Length;
            string jsonObject = Whbost.Common.systemDefault.ListToJson(menuList);
            return jsonObject;
        }
        ///<summary>
        /// 获取用户系统菜单,select型{0,表示不在菜单列表中显示的页面|1,表示在菜单列表中显示的页面|2,表示显示全部菜单页面|3,表示只显示全部的主菜单}
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="isShow"></param>
        /// <returns></returns>
        public string UserMenu_list_json_select(string user_id, int isShow)
        {

            List<ISys_Menu_User> menuList = db.DLL_UserMenu_list(user_id, isShow);
            List<IAjaxSelect> sl = (from s in menuList
                              select new IAjaxSelect()
                              {
                                  id = s.menu_no,
                                  text = s.menu_name,
                                  value = s.menu_no
                              }).ToList();
         //   total = menuList.ToArray().Length;
            string jsonObject = Whbost.Common.systemDefault.ListToJson(sl);
            return jsonObject;
        }
        /// <summary>
        /// 获取用户系统菜单,网格型
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="isShow"></param>
        /// <returns></returns>
        public string UserMenu_list_json_grid(string user_id, int isShow, int _pagenumber, int _pagesize)
        {
            List<ISys_Menu_User> menuList = db.DLL_UserMenu_list(user_id, isShow);
            total = menuList.ToArray().Length;
            if (_pagenumber > 0 && _pagesize > 0)
            {
                menuList = menuList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            string jsonObject = Whbost.Common.systemDefault.ListToJson(menuList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + total + @"""}";
            return json;
        }
        /// <summary>
        /// 获取用户系统子菜单,网格型
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="isShow"></param>
        /// <returns></returns>
        public string UserMenu_next_list_json_grid(string user_id, int _pagenumber, int _pagesize,string menu_no)
        {
            List<ISys_Menu_User> menuList = db.DLL_System_menu_next(menu_no);
          //  menuList = menuList.Where(p => p.menu_parent_no == menu_no).ToList();
            total = menuList.ToArray().Length;
            if (_pagenumber > 0 && _pagesize > 0)
            {
                menuList = menuList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            string jsonObject = Whbost.Common.systemDefault.ListToJson(menuList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + total + @"""}";
            return json;
        }
        /// <summary>
        /// 获取菜单的小图标
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public AjaxResult UserMenu_getIcons(string rootPath)
        {
            try
            {
                //var cache = CacheHelper.Get("SystemIcons");
                //if (cache != null)
                //{
                //    return AjaxResult.Success(cache);
                //}
               // var rootPath = Server.MapPath("~/lib/icons/");
                string dirPath = rootPath + "32X32\\";
                var files = System.IO.Directory.GetFiles(dirPath);

                //缓存一天吧
               // CacheHelper.Insert("SystemIcons", files, 60 * 60 * 24);
                return AjaxResult.Success(files);
            }
            catch (Exception err)
            {
                return AjaxResult.Error("函数：GetIcons:" + err.Message);
            }
        }
        /// <summary>
        /// 显示页面操作按钮
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="menu_no"></param>
        /// <returns></returns>
        public string UserBtn_json(string user_id, string menu_no)
        {
            List<ISys_button> btnlist = db.DLL_UserBtn_menuNo(user_id, menu_no);
            string jsonObject = Whbost.Common.systemDefault.ListToJson(btnlist);
            return jsonObject;
        }
        /// <summary>
        /// 获取主菜单信息
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public string Sysmenu_json_one(string menu_id)
        {
            ISys_Menu sysmenu = db.DLL_Sysmenu_one(menu_id);
            string jsonObject = Whbost.Common.systemDefault.ListToJson_one(sysmenu);
            return jsonObject;
        }
        /// <summary>
        /// 获取menu_no主菜单信息
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public string sys_menu_one_bymenu_no_select(string menu_no)
        {
            ISys_Menu sysmenu = db.DLL_Sysmenu_one_bymenu_no_select(menu_no);
            string jsonObject = Whbost.Common.systemDefault.ListToJson_one(sysmenu);
            return jsonObject;
        }
        /// <summary>
        /// 删除主菜单
        /// </summary>
        /// <param name="menu_id"></param>
        /// <returns></returns>
        public bool Sysmenu_del(string menu_id)
        {
            return db.DLL_Sysmenu_del(menu_id);
        }
        public bool Sysmenu_add(NameValueCollection form)
        {
             return db.DLL_Sysmenu_add(form);
        }
        public bool Sysmenu_modify(NameValueCollection form)
        {
            return db.DLL_Sysmenu_modify(form);
        }

    }
}
