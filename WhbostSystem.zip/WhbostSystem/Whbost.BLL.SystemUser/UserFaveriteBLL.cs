﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.Intrefaces;

namespace Whbost.BLL.SystemUser
{
    public class UserFaveriteBLL
    {
        /// <summary>
        /// 获取客户便捷方式数据的JSON格式
        /// </summary>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public string UserFaverite_list_json(string user_id)
        {
            DLL.User.UserDLL db=new Whbost.DLL.User.UserDLL();
            List<ICF_user_favorite> jsonList = db.DLL_User_favorite_list(user_id);
            string jsonObject = Whbost.Common.systemDefault.ListToJson(jsonList);
            return jsonObject;
        }
        public bool UserFaverite_modify(string menu_id,string favoriteContent,string favorite_id, string user_id)
        {
            DLL.User.UserDLL db = new Whbost.DLL.User.UserDLL();
            return db.DLL_User_favorite_modify(new ICF_user_favorite { create_date = System.DateTime.Now.ToUniversalTime(), favorite_content = favoriteContent, menu_id = menu_id, user_id = user_id,favorite_id=favorite_id}, user_id);
        }
    }
}
