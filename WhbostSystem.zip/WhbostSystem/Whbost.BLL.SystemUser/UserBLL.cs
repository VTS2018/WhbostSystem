﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Whbost.Intrefaces;
using Whbost.Common.AjaxRequest;
using System.Management;
using System.Net;
namespace Whbost.BLL.SystemUser
{
    public class UserBLL
    {
        /// <summary>
        /// 管理员登录验证
        /// </summary>
        /// <returns></returns>
        public AjaxResult User_login(string userName, string userPwd)
        {
            AjaxResult ajaxResult = null;
            string resultMessage = string.Empty;
            int login_state = 0;
            userPwd = Whbost.Common.systemDefault.DataToMd5(userPwd);
            //获取客户的电脑IP和MAC信息
            string currMac = Computer_LocalMac();
            currMac = currMac.Replace("-", ":");
            string currIP = Computer_LocalIP();
            DLL.User.UserDLL db = new Whbost.DLL.User.UserDLL();
            //1.验证用户名是否有效，在同一天内出错的次数是否大于5次
            bool objErrCount = db.User_errorLoginCount(userName);
            if (objErrCount)
            {
                resultMessage = "错误提示：输入错误超过限制!用户名被锁!";
                ajaxResult = AjaxResult.Error(resultMessage);
                return ajaxResult;
            }
            //2.验证用户名，密码是否正确
            bool objUser = db.DLL_User_login(userName, userPwd);
            if (objUser)
            {
                //3.MAC地址验证
                ICF_user userData = db.User_getAccount(userName);
                if (userData.IsVisible_mac == 1)
                {
                    if (db.User_checkMac(userData.user_id, currMac) == true)
                    {
                        login_state = 1;
                        resultMessage = "MAC地址验证通过,登录成功!";
                        ajaxResult = AjaxResult.Success(resultMessage);
                    }
                    else
                    {
                        resultMessage = "错误提示：设备mac没有授权,请联系管理员!";
                        ajaxResult = AjaxResult.Error(resultMessage);
                    }
                }
                else
                {
                    login_state = 1;
                    resultMessage = "MAC验证没开启,登录成功!";
                    ajaxResult = AjaxResult.Success(resultMessage);
                }
            }
            else
            {
                resultMessage = "错误提示：登录失败,账户密码错误!";
                ajaxResult = AjaxResult.Error(resultMessage);
            }
            //记录客户的登录日志和操作日志
            DateTime dt = System.DateTime.Now.ToUniversalTime();
            if (db.User_saveLoginLog(new ICF_user_loginlog()
            {
                login_date = dt,
                login_ip = currIP,
                login_mac = currMac,
                login_remark = resultMessage,
                login_state = login_state,
                user_name = userName
            }) == true && db.User_saveOperateLog(new ICF_user_operatelog()
            {
                create_date = dt,
                operate_type = "账户登录",
                user_name = userName,
                operate_content = "设备IP：" + currIP + ",设备MAC:" + currMac + ",登录状态:" + resultMessage + ""
            }) == true)
            {
                resultMessage = "错误提示：登录日志，操作记录失败!";
              //  ajaxResult = AjaxResult.Error(resultMessage);
            }
            else
            {
                resultMessage = "登录日志，操作记录已完成!";
              //  ajaxResult = AjaxResult.Success(resultMessage);
            }
                /////////////////////////////
                return ajaxResult;
        }
        /// <summary>
        /// 获取客户端MAC地址
        /// </summary>
        /// <returns></returns>
        public string Computer_LocalMac()
        {
            string mac = null;
            ManagementObjectSearcher query = new ManagementObjectSearcher("SELECT * FROM Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection queryCollection = query.Get();
            foreach (ManagementObject mo in queryCollection)
            {
                if (mo["IPEnabled"].ToString() == "True")
                    mac = mo["MacAddress"].ToString();
            }
            return (mac);
        }
        /// <summary>
        /// 获取客户端的IP
        /// </summary>
        /// <returns></returns>
        public string Computer_LocalIP()
        {
            string strHostName = Dns.GetHostName(); //得到本机的主机名
            IPHostEntry ipEntry = Dns.GetHostEntry(strHostName); //取得本机IP
            string strAddr = ipEntry.AddressList[0].ToString();
            return (strAddr);
        }
        /// <summary>
        /// 获取用户user_id
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public string User_Back_userid(string userName)
        {
            DLL.User.UserDLL db = new Whbost.DLL.User.UserDLL();
            ICF_user objUser = db.User_getAccount(userName);
            if (objUser != null)
                return objUser.user_id;
            else
                return string.Empty;
        }
    }
}
