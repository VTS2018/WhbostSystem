﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
namespace Whbost.Common
{
    public class systemDefault
    {
        public static int addTime = 8;
        public static string falseMessage = "错误提示：数据操作失败!";
        public static string trueMessage = "数据操作成功!!";
        /// <summary>
        ///静态的生成数据库10位字符随机码，注意区分大小写
        /// </summary>
        private static char[] constant = { '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        public static string GenerateRandom()
        {
            int Length = 10;
            System.Text.StringBuilder newRandom = new System.Text.StringBuilder(36);
            Random rd = new Random();
            for (int i = 0; i < Length; i++)
            {
                newRandom.Append(constant[rd.Next(36)]);
            }
            return newRandom.ToString();
        }
        /// <summary>
        ///标准时间转换为当前时间
        /// </summary>
        public static string TimeToLocation(string dateTime)
        {
            return (dateTime != string.Empty ? Convert.ToDateTime(dateTime).AddHours(systemDefault.addTime).ToString("yyyy/MM/dd HH:mm") : "");;
        }
        /// <summary>
        /// 标准时间转换为当前时间短格式
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public static string TimeToLocation_Short(string dateTime)
        {
            return (dateTime != string.Empty ? Convert.ToDateTime(dateTime).AddHours(systemDefault.addTime).ToString("yyyy/MM/dd") : ""); ;
        }
        /// <summary>
        /// List转换成Json 。主要用于进行网格显示
        /// </summary>
        public static string ListToJson<T>(IList<T> list)
        {
            return new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(list);
        }
        /// <summary>
        /// json格式转换
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="strJson"></param>
        /// <returns></returns>
        public static T FromJson<T>(string strJson) where T : class
        {
            if (strJson != null && strJson != string.Empty)
                return new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<T>(strJson);
            else
                return null;
        }
        /// <summary>
        /// 1条记录转换成Json 主要用于 数据的单条展示。
        /// </summary>
        public static string ListToJson_one(object list)
        {
            return new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(list);
        }
        /// <summary>
        /// 函数运行出现错误时，写错误代码到文本
        /// </summary>
        /// <param name="funcName">函数名</param>
        /// <param name="ex">错误原因</param>
        public static void WriteError(string funcName,string ex)
        {
            //获取错误函数的存放位置
            string logPath = ConfigurationManager.AppSettings["ServerPath"] + ConfigurationManager.AppSettings["ErrorLogPath"];
            //写文件内容
            string txtContent = TimeToLocation(DateTime.Now.ToUniversalTime().ToString()) + ":" + "  " + funcName + "\r\n" + ex + "";
            StreamWriter wr = new StreamWriter(logPath, true, System.Text.Encoding.Default);
            wr.Write(txtContent);
            wr.Flush();
            wr.Close();
        }
        /// <summary>
        ///数据D5加密
        /// </summary>
        public static string DataToMd5(string data)
        {
            string cl = data;
            string pwd = string.Empty;
            MD5 md5 = MD5.Create();//实例化一个md5对像
            // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
            byte[] s = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(cl));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符
                pwd = pwd + s[i].ToString("X");

            }
            return StringTrans(pwd);
        }
      /// <summary>
      /// 删除服务器图片
      /// </summary>
      /// <param name="picPath">图片的文件夹地址</param>
      /// <param name="picName">图片名称</param>
      /// <returns></returns>
        public static bool DeletePic(string FolderPath,string picName)
        {
            try
            {
                string picPath = FolderPath + "/" + picName;//原图地址
                string bPath = FolderPath + "/" + picName.Substring(0, picName.LastIndexOf(".")) + "_b" + "." + picName.Substring(picName.LastIndexOf(".") + 1);//大图地址
                string mPath = FolderPath + "/" + picName.Substring(0, picName.LastIndexOf(".")) + "_m" + "." + picName.Substring(picName.LastIndexOf(".") + 1);//中图地址
                string sPath = FolderPath + "/" + picName.Substring(0, picName.LastIndexOf(".")) + "_s" + "." + picName.Substring(picName.LastIndexOf(".") + 1);//小图地址
                //删除小图
                string Spath = System.Web.HttpContext.Current.Server.MapPath(sPath);
                System.IO.FileInfo Sfile = new System.IO.FileInfo(Spath);
                if (Sfile.Exists)
                    Sfile.Delete();
                //删除中图
                string Mpath = System.Web.HttpContext.Current.Server.MapPath(mPath);
                System.IO.FileInfo Mfile = new System.IO.FileInfo(Mpath);
                if (Mfile.Exists)
                    Mfile.Delete();
                //删除大图
                string Bpath = System.Web.HttpContext.Current.Server.MapPath(bPath);
                System.IO.FileInfo Bfile = new System.IO.FileInfo(Bpath);
                if (Bfile.Exists)
                    Bfile.Delete();
                //删除原图
                string Opath = System.Web.HttpContext.Current.Server.MapPath(picPath);
                System.IO.FileInfo Ofile = new System.IO.FileInfo(Opath);
                if (Ofile.Exists)
                    Ofile.Delete();
                return true;
            }
            catch
            {
                return false;
            }
           
        }
        /// <summary>
        /// 删除文件
        /// </summary>
        /// <param name="FolderPath"></param>
        /// <param name="picName"></param>
        /// <returns></returns>
        public static bool DeleteFile(string FilePath)
        {
            string path = System.Web.HttpContext.Current.Server.MapPath(FilePath);
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            {
                try { file.Delete(); return true; }
                catch { return false; }
            }
            else { return true; }
        }
        /// <summary>
        /// 判断文件地址是否存在
        /// </summary>
        public static bool IsExistFolder(string url)
        {
            string path = System.Web.HttpContext.Current.Server.MapPath(url);
            System.IO.FileInfo file = new System.IO.FileInfo(path);
            if (file.Exists)
            { return true; }
            else { return false; }
        }
        /// <summary>
        /// 将字符串变成小写并去掉后面的空格
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string StringTrans(string str)
        {
            return str != string.Empty ? str.ToLower().Trim() : null;
        }
        /// <summary>
        /// 将不存在的值，转化为空的string,并且全部转化为小写
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReturnString(object str)
        {
            return (str != null) ? StringTrans(str.ToString()) : null;
        }
        /// <summary>
        /// 将不存在的值，转化为初始的string,并且全部转化为小写。
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReturnString_default(object str,string defaultValue)
        {
            defaultValue = (defaultValue != null ? defaultValue :null);
            return (str != null ) ? StringTrans(str.ToString()) : defaultValue;
        }
        /// <summary>
        /// 将不存在的值，转化为空的string。注意：不进行大小写更改
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReturnString_normal(object str)
        {
            return (str != null) ? (str.ToString()!=string.Empty?str.ToString().Trim():null) : null;
        }
        /// <summary>
        /// 将不存在的值，转化为初始的string。注意：不进行大小写更改
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReturnString_default_normal(object str, string defaultValue)
        {
            defaultValue = (defaultValue != null ? defaultValue : null);
            return (str != null) ? (str.ToString() != string.Empty ? str.ToString().Trim() : null) : defaultValue;
        }
        /// <summary>
        /// 将不存在的值，转化为空的int=0。
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static int ReturnInt(object str)
        {
            return (str != null) ? (str.ToString() != string.Empty?Convert.ToInt32(str.ToString()):0) : 0;
        }
        /// <summary>
        /// 将不存在的值，转化为空的int=default。可以传默认值
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static int ReturnInt_default(object str,int defaultValue)
        {
            return (str != null) ?(str.ToString() != string.Empty?Convert.ToInt32(str.ToString()):defaultValue) : defaultValue;
        }
        /// <summary>
        /// 生成HIDDEN的HTML格式
        /// </summary>
        /// <param name="hdid">隐藏控件ID</param>
        /// <param name="hdname">隐藏控件值</param>
        /// <returns></returns>
        public static string ReturnHiddenHTML(string hdid, string hdname)
        {
            return "<input type=\"hidden\" id=\"" + hdid + "\" value=\"" + hdname + "\" />\n";
        }
        /// <summary>
        /// 返回bool值的前端显示信息
        /// </summary>
        /// <param name="boolValue"></param>
        /// <param name="trueMessage"></param>
        /// <param name="falseMessage"></param>
        /// <returns></returns>
        public static string ReturnBoolMessage(bool boolValue, string trueMessage, string falseMessage)
        {
            return boolValue ? trueMessage : falseMessage;
        }
        /// <summary>
        /// 网店模板图片地址
        /// </summary>
        /// <returns></returns>
        public static string ReturnPath_Site()
        {
            return "/UploadFile/SiteMaster/";
        }
        /// <summary> 
        /// 生成缩略图 
        /// </summary> 
        /// <param name="originalImagePath">源图路径（物理路径）</param> 
        /// <param name="thumbnailPath">缩略图路径（物理路径）</param> 
        /// <param name="width">缩略图宽度</param> 
        /// <param name="height">缩略图高度</param> 
        /// <param name="mode">生成缩略图的方式</param> 
        public static void MakeThumbnail(string originalImagePath, string thumbnailPath, int width, int height, string mode)
        {
            System.Drawing.Image originalImage = System.Drawing.Image.FromFile(originalImagePath);

            int towidth = width;
            int toheight = height;

            int x = 0;
            int y = 0;
            int ow = originalImage.Width;
            int oh = originalImage.Height;

            switch (mode)
            {
                case "HW"://指定高宽缩放（可能变形） 
                    break;
                case "W"://指定宽，高按比例 
                    toheight = originalImage.Height * width / originalImage.Width;
                    break;
                case "H"://指定高，宽按比例 
                    towidth = originalImage.Width * height / originalImage.Height;
                    break;
                case "Cut"://指定高宽裁减（不变形） 
                    if ((double)originalImage.Width / (double)originalImage.Height > (double)towidth / (double)toheight)
                    {
                        oh = originalImage.Height;
                        ow = originalImage.Height * towidth / toheight;
                        y = 0;
                        x = (originalImage.Width - ow) / 2;
                    }
                    else
                    {
                        ow = originalImage.Width;
                        oh = originalImage.Width * height / towidth;
                        x = 0;
                        y = (originalImage.Height - oh) / 2;
                    }
                    break;
                default:
                    break;
            }

            //新建一个bmp图片 
            System.Drawing.Image bitmap = new System.Drawing.Bitmap(towidth, toheight);

            //新建一个画板 
            System.Drawing.Graphics g = System.Drawing.Graphics.FromImage(bitmap);

            //设置高质量插值法 
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;

            //设置高质量,低速度呈现平滑程度 
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

            //清空画布并以透明背景色填充 
            g.Clear(System.Drawing.Color.Transparent);

            //在指定位置并且按指定大小绘制原图片的指定部分 
            g.DrawImage(originalImage, new System.Drawing.Rectangle(0, 0, towidth, toheight),
            new System.Drawing.Rectangle(x, y, ow, oh),
            System.Drawing.GraphicsUnit.Pixel);

            try
            {
                //以jpg格式保存缩略图 
                bitmap.Save(thumbnailPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            catch (System.Exception e)
            {
                throw e;
            }
            finally
            {
                originalImage.Dispose();
                bitmap.Dispose();
                g.Dispose();
            }
        }
    }
}
