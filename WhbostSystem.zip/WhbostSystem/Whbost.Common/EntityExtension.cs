﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;
using System.Reflection;

namespace Whbost.Common
{
    public static class EntityExtension
    {

        public static void Load(object entity, NameValueCollection coll)
        {
            if (coll == null) return;
            foreach (var key in coll.AllKeys)
            {
                var prop = entity.GetType().GetProperty(key);
                if (prop != null)
                {
                    if (coll[key] != string.Empty)
                    {
                        var propValue = ConvertValue(prop.PropertyType, coll[key]);
                        prop.SetValue(entity, propValue, null);
                    }
                    else if (prop.PropertyType == typeof(string))
                    {
                        prop.SetValue(entity, null, null);
                    }
                }
            }
        }

        public static object ConvertValue(Type type, object value)
        {
            if (type == typeof(string))
            {
                return value;
            }


            MethodInfo parseMethod = null;


            foreach (MethodInfo mi in type.GetMethods(BindingFlags.Static
            | BindingFlags.Public))
            {
                if (mi.Name == "Parse" && mi.GetParameters().Length == 1)
                {
                    parseMethod = mi;
                    break;
                }
            }


            if (parseMethod == null)
            {
                throw new ArgumentException(string.Format(
                "Type: {0} has not Parse static method!", type));
            }


            return parseMethod.Invoke(null, new object[] { value });
        }
    }
}
