﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common;
using Whbost.DLL;

namespace Whbost.BLL.ALL
{
    public class SiteMasterBLL
    {
        /// <summary>
        /// 获取模板的网格数据
        /// </summary>
        private int arrTotal = 0; //Jhon格式中返回记录总数
        private string jsonObject = string.Empty; //Json数据集格式
        private string json = string.Empty; //Json返回结果
        /// <summary>
        /// 示例，显示网格信息
        /// </summary>
        /// <param name="sortname">排序的字段</param>
        /// <param name="sortorder"></param>
        /// <param name="where"></param>
        /// <param name="_pagenumber"></param>
        /// <param name="_pagesize"></param>
        /// <returns></returns>
        public string SiteMaster_Json_DataGrid(string sortname, string sortorder, string where, int _pagenumber, int _pagesize)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            ISite_master_collection iSite_master_collection = new ISite_master_collection();

            List<ISite_master_collection> arrList = db.DLL_SiteMaster_list();
            //对List数据进行条件搜索

            // 获取数据记总数
            arrTotal = arrList.ToArray().Length;
            //对LIST数据进行排序
            if (sortname != null && sortname != string.Empty)
            {
                Whbost.Common.sortby.Reverser<ISite_master_collection> reverser = new Whbost.Common.sortby.Reverser<ISite_master_collection>(iSite_master_collection.GetType(), sortname, sortorder == "desc" ? (Whbost.Common.sortby.ReverserInfo.Direction.DESC) : Whbost.Common.sortby.ReverserInfo.Direction.ASC);
                arrList.Sort(reverser);
            }
            //对LIST数据进行分页
            if (_pagenumber > 0 && _pagesize > 0)
            {
                arrList = arrList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            jsonObject = Whbost.Common.systemDefault.ListToJson(arrList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + arrTotal + @"""}";
            return json;
        }
        /// <summary>
        /// 删除模板
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool SiteMaster_add(NameValueCollection form)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            return db.DLL_SiteMaster_add(form);
        }
        /// <summary>
        /// 获取模板数据
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public string SiteMaster_view(string SiteMaster_id)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            ISite_master_collection zdata = db.DLL_SiteMaster_view(SiteMaster_id);
            return Whbost.Common.systemDefault.ListToJson_one(zdata);
        }
        /// <summary>
        /// 编辑模板
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public bool SiteMaster_modify(NameValueCollection form)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            return db.DLL_SiteMaster_modify(form);
        }
        /// <summary>
        /// 删除模板
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public bool SiteMaster_del(string SiteMaster_id)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            return db.DLL_SiteMaster_del(SiteMaster_id);
        }
        /// <summary>
        /// 添加模板图片
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <param name="imgValue"></param>
        /// <returns></returns>
        public bool SiteMaster_img_add(string SiteMaster_id, string imgValue)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            return db.DLL_SiteMaster_img_add(SiteMaster_id,imgValue);
        }
        /// <summary>
        /// 获取模板图片列表
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <returns></returns>
        public string SiteMaster_img_getValue(string SiteMaster_id)
        {
            DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
            return db.DLL_SiteMaster_img_getValue(SiteMaster_id);
        }
        /// <summary>
        /// 删除模板图片
        /// </summary>
        /// <param name="SiteMaster_id"></param>
        /// <param name="imgValue"></param>
        /// <returns></returns>
        public bool SiteMaster_img_del(string SiteMaster_id, string imgValue)
        {
            //1.先删除图片
            string imgPath = Whbost.Common.systemDefault.ReturnPath_Site()+SiteMaster_id+"/"+ imgValue;
            if (Whbost.Common.systemDefault.DeletePic((Whbost.Common.systemDefault.ReturnPath_Site() + SiteMaster_id), imgValue))
            {
                DLL.Site.SiteMasterDLL db = new Whbost.DLL.Site.SiteMasterDLL();
                return db.DLL_SiteMaster_img_del(SiteMaster_id, imgValue);
            }
            else
                return false;
        }
    }
}