﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common;
using Whbost.DLL;

namespace Whbost.BLL.ALL
{
    public class SEOBLL
    {
        private int arrTotal = 0; //Jhon格式中返回记录总数
        private string jsonObject = string.Empty; //Json数据集格式
        private string json = string.Empty; //Json返回结果

        #region LINKS 外链部分
     
        /// <summary>
        /// 外链数据集合
        /// </summary>
        /// <param name="sortname">排序字段</param>
        /// <param name="sortorder">排序规则</param>
        /// <param name="where">额外查询条件</param>
        /// <param name="_pagenumber">当前页面</param>
        /// <param name="_pagesize">每页条数</param>
        /// <returns></returns>
        public string SEO_Links_Json_DataGird(string sortname, string sortorder, string where, int _pagenumber, int _pagesize)
        {
            DLL.SEO.LinksDLL db = new Whbost.DLL.SEO.LinksDLL();
            iLink_collection_page ilink_collection_page = new iLink_collection_page();
            List<iLink_collection_page> linksList = db.DLL_Links_DataGrid();
            //对List数据进行搜索
            FilterGroup filter = Common.systemDefault.FromJson<FilterGroup>(where);
            //end搜索
            // 获取数据记总数
            arrTotal = linksList.ToArray().Length;
              //对LIST数据进行排序
            if (sortname != null && sortname != string.Empty)
            {
                Whbost.Common.sortby.Reverser<iLink_collection_page> reverser = new Whbost.Common.sortby.Reverser<iLink_collection_page>(ilink_collection_page.GetType(), sortname, sortorder == "desc" ? (Whbost.Common.sortby.ReverserInfo.Direction.DESC) : Whbost.Common.sortby.ReverserInfo.Direction.ASC);
                linksList.Sort(reverser);
            }
            //对LIST数据进行分页
            if (_pagenumber > 0 && _pagesize > 0)
            {
                linksList = linksList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            jsonObject = Whbost.Common.systemDefault.ListToJson(linksList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + arrTotal + @"""}";
            return json;
        }
        #endregion
    }
}
