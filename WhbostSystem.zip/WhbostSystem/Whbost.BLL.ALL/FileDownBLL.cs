﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common;
using Whbost.DLL;

namespace Whbost.BLL.ALL
{
    public class FileDownBLL
    {
        /// <summary>
        /// 添加文件
        /// </summary>
        /// <param name="filedesc"></param>
        /// <param name="filename"></param>
        /// <param name="filefolderpath"></param>
        /// <param name="user_id"></param>
        /// <returns></returns>
        public bool Filedown_add(string filedesc, string filename, string filefolderpath, string user_id,string file_id)
        {
            DLL.File.FileDownDLL db = new Whbost.DLL.File.FileDownDLL();
            return db.DLL_Filedown_add(new IFile_down()
            {
                file_create_user_id = user_id,
                file_createdate = System.DateTime.Now.ToUniversalTime(),
                file_desc = filedesc,
                file_down_id = Guid.NewGuid(),
                file_folderpath = filefolderpath,
                file_id = file_id,
                file_name = filename
            });
        }
        /// <summary>
        /// 读取文件列表用于grid显示
        /// </summary>
        /// <param name="file_id"></param>
        /// <returns></returns>
        public string Filedown_list(string file_id)
        {
            DLL.File.FileDownDLL db = new Whbost.DLL.File.FileDownDLL();
            List<IFile_down> list=db.DLL_Filedown_list(file_id);
            string jsonObject = Whbost.Common.systemDefault.ListToJson(list);
            jsonObject = @"{""Rows"":" + jsonObject + @",""Total"":""" + list.ToArray().Length + @"""}";
            return jsonObject;
        }
        /// <summary>
        /// 删除文件
        /// </summary>
        /// <param name="filedown_id"></param>
        /// <returns></returns>
        public bool Filedown_del(string filedown_id)
        {
            DLL.File.FileDownDLL db = new Whbost.DLL.File.FileDownDLL();
            return
                db.DLL_Filedown_del(filedown_id);
        }
    }
}
