﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;
using Whbost.Intrefaces;
using Whbost.Common;
using Whbost.DLL;

namespace Whbost.BLL.ALL
{
    public class SysCommonBLL
    {
        private int arrTotal = 0; //Jhon格式中返回记录总数
        private string jsonObject = string.Empty; //Json数据集格式
        private string json = string.Empty; //Json返回结果

        #region 系统分类选择
        /// <summary>
        /// 常用系统分类网格数据
        /// </summary>
        public string Sys_Common_Category_DataGrid(string sortname, string sortorder, string where, int _pagenumber, int _pagesize,int isValid)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            ICategory iCategory = new ICategory();
         //   List<ICategoryInfo> arrList_1 = db.DLL_SysCommon_CategoryInfo(isValid);
            List<ICategory> arrList = db.DLL_SysCommon_Category(isValid);
            //对List数据进行条件搜索

            // 获取数据记总数
            arrTotal = arrList.ToArray().Length;
            //对LIST数据进行排序
            if (sortname != null)
            {
                Whbost.Common.sortby.Reverser<ICategory> reverser = new Whbost.Common.sortby.Reverser<ICategory>(iCategory.GetType(), sortname, sortorder == "desc" ? (Whbost.Common.sortby.ReverserInfo.Direction.DESC) : Whbost.Common.sortby.ReverserInfo.Direction.ASC);
                arrList.Sort(reverser);
            }
            //对LIST数据进行分页
            if (_pagenumber > 0 && _pagesize > 0)
            {
                arrList = arrList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            jsonObject = Whbost.Common.systemDefault.ListToJson(arrList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + arrTotal + @"""}";
            return json;
        }
        /// <summary>
        /// 常用系统分类选择属性值网格数据
        /// </summary>
        public string Sys_Common_Category_SelectValue_DataGrid(string sortname, string sortorder, string where, int _pagenumber, int _pagesize, string category_id)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            ICategory_selectValue iCategory_selectValue = new ICategory_selectValue();
            //   List<ICategoryInfo> arrList_1 = db.DLL_SysCommon_CategoryInfo(isValid);
            List<ICategory_selectValue> arrList = db.DLL_SysCommon_Category_SelectValue(category_id);
            //对List数据进行条件搜索

            // 获取数据记总数
            arrTotal = arrList.ToArray().Length;
            //对LIST数据进行排序
            if (sortname != null)
            {
                Whbost.Common.sortby.Reverser<ICategory_selectValue> reverser = new Whbost.Common.sortby.Reverser<ICategory_selectValue>(iCategory_selectValue.GetType(), sortname, sortorder == "desc" ? (Whbost.Common.sortby.ReverserInfo.Direction.DESC) : Whbost.Common.sortby.ReverserInfo.Direction.ASC);
                arrList.Sort(reverser);
            }
            //对LIST数据进行分页
            if (_pagenumber > 0 && _pagesize > 0)
            {
                arrList = arrList.Skip(_pagesize * (_pagenumber - 1)).Take(_pagesize).ToList();
            }
            jsonObject = Whbost.Common.systemDefault.ListToJson(arrList);
            json = @"{""Rows"":" + jsonObject + @",""Total"":""" + arrTotal + @"""}";
            return json;
        }
        /// <summary>
        /// 获取单个分类数据
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public string Sys_Common_Category_One(string category_id)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return Whbost.Common.systemDefault.ListToJson_one(db.DLL_SysCommon_Category_one(category_id));
        }
        /// <summary>
        /// 编辑分类数据
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public bool Sys_Common_Category_Modify(NameValueCollection form)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return db.DLL_SysCommon_Category_modify(form);
        }
        /// <summary>
        /// 添加分类数据
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public bool Sys_Common_Category_Add(NameValueCollection form)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return db.DLL_SysCommon_Category_add(form);
        }
        /// <summary>
        /// 添加分类选项值数据
        /// </summary>
        /// <param name="category_id"></param>
        /// <returns></returns>
        public bool Sys_Common_Category_SelectValue_Add(NameValueCollection form)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return db.DLL_SysCommon_Category_SelectValue_add(form);
        }
        /// <summary>
        /// 获取分类选项的选项值
        /// </summary>
        /// <param name="category_selectvalue_id"></param>
        /// <returns></returns>
        public string Sys_Common_Category_SelectVaule_One(string category_selectvalue_id)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return Whbost.Common.systemDefault.ListToJson_one(db.DLL_SysCommon_Category_SelectValue_one(category_selectvalue_id));
        }
        public bool Sys_Common_Category_SelectVaule_Del(string category_selectvalue_id)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return db.DLL_SysCommon_Category_SelectValue_del(category_selectvalue_id);
        }
        public bool Sys_Common_Category_SelectVaule_Modify(NameValueCollection form)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            return db.DLL_SysCommon_Category_SelectValue_modify(form);
        }
/// <summary>
/// 系统选择项SELECT格式
/// </summary>
        public string Sys_Common_Select_json(string category_field)
        {
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            List<ICategory_selectValue> arrList = db.DLL_SysCommon_Category_SelectValue_byfiled(category_field);
            List<IAjaxSelect> sl = new List<IAjaxSelect>();
            
            sl = (from s in arrList
                  select new IAjaxSelect()
                  {
                      id = s.category_selectvalue_id,
                      text = s.category_selectvalue_text,
                      value = s.category_selectvalue_id
                  }).ToList();
            sl.Add(new IAjaxSelect() { id = "", text = "请选择...", value = "" });
            //   total = menuList.ToArray().Length;
            string jsonObject = Whbost.Common.systemDefault.ListToJson(sl);
            return jsonObject;
        }
        public string Sys_Common_Select_HTML(string category_field,string selectName,string defaultText)
        {
            string selectHTML = string.Empty;
        
            DLL.Common.SysCommonDLL db = new Whbost.DLL.Common.SysCommonDLL();
            ICategory cate = db.DLL_SysCommon_Category_one_field(category_field);
            if (cate != null)
            {
                string selectLable = cate.category_name;
                selectHTML = "<select id=\"" + selectName + "\">\n";
                if (defaultText == null || defaultText == string.Empty)
                {
                    defaultText = "全部值";
                }
                selectHTML += "<option value=\"\">" + defaultText + "</option>\n";
                List<ICategory_selectValue> arrList = db.DLL_SysCommon_Category_SelectValue_byfiled(category_field);
                if (arrList != null && arrList.ToArray().Length > 0)
                {
                    for (int i = 0; i < arrList.ToArray().Length; i++)
                    {
                        selectHTML += "<option value=\"" + arrList[i].category_selectvalue_id + "\">" + arrList[i].category_selectvalue_text + "</option>\n";
                    }
                }
                selectHTML += "</select>\n";
                selectHTML = "<font style=\"padding:3px;8px\">"+selectLable + " : " +"</font>"+ selectHTML;
            }
            else
            {
                selectHTML = "数据不存在!";
            }
            return selectHTML;
        }
        #endregion
    }
}
