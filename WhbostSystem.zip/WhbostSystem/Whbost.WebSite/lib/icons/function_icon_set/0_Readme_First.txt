

Function Free Icon Set

---

http://www.wefunction.com

---

This Set was brought to you by Function
Design & Development Studio.

Make sure you share these Icons using this
link only: 

http://wefunction.com/2008/07/function-free-icon-set/

---

We're looking for New Clients for Web Design & Blog
Design Projects, we build and design fully unique
design & development solutions

---

contact: liam@wefunction.com

Website: www.wefunction.com