﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Collections.Specialized;
using System.Web.SessionState;
using Whbost.Common.AjaxRequest;

namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/", Description = "处理返回结果返回格式为data的数据")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ResultIcon : IHttpHandler, IRequiresSessionState
    {
        private AjaxResult ajaxResult = null;
        private string ashxFunc = string.Empty; //需要执行的函数块
        private string func = "ResultData.ashx"; //执行运算的主函数
        NameValueCollection form = new NameValueCollection();
        public void ProcessRequest(HttpContext context)
        {
            string user_id =BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
            try
            {
                context.Response.ContentType = "text/plain";
                form = context.Request.Form;
                ashxFunc = Whbost.Common.systemDefault.ReturnString(form["ashxFunc"]);
                switch (ashxFunc)
                {
                    #region 系统
                    case "sys_icon":
                        Whbost.BLL.SystemUser.UserMenuBLL db = new Whbost.BLL.SystemUser.UserMenuBLL();
                        string rootPath = System.Web.HttpContext.Current.Server.MapPath("~/lib/icons/");
                        ajaxResult = db.UserMenu_getIcons(rootPath);
                        break;
                    case "sys_menu":
                        Whbost.BLL.SystemUser.UserMenuBLL db1 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        ajaxResult =AjaxResult.Success(db1.UserMenu_list_json_select(user_id, 3));
                        break;
                    #endregion

                    #region 各种图片的值系列
                    case "sitemaster_img":
                        Whbost.BLL.ALL.SiteMasterBLL site = new Whbost.BLL.ALL.SiteMasterBLL();
                        string sitemaster_id = Whbost.Common.systemDefault.ReturnString(context.Request["sitemaster_id"]);
                        ajaxResult = AjaxResult.Success(site.SiteMaster_img_getValue(sitemaster_id));
                        break;
                    #endregion

                    #region 自定义的AJAX的Select
                    case "select":
                        Whbost.BLL.ALL.SysCommonBLL select = new Whbost.BLL.ALL.SysCommonBLL();
                        string selectfield = Whbost.Common.systemDefault.ReturnString(context.Request["selectfield"]);
                        string selectname = Whbost.Common.systemDefault.ReturnString(context.Request["selectname"]);
                        string defaulttext = Whbost.Common.systemDefault.ReturnString(context.Request["defaulttext"]);
                        ajaxResult = AjaxResult.Success(select.Sys_Common_Select_HTML(selectfield, selectname, defaulttext));
                        break;
                    #endregion

                }
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                ajaxResult = AjaxResult.Error(ex.ToString());
            }
            context.Response.Write(ajaxResult);
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
