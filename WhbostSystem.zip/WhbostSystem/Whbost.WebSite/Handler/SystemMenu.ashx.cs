﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Web.SessionState;

namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class SystemMenu : IHttpHandler, IRequiresSessionState
    {

        /// <summary>
        /// 视图自定义加载函数列表
        /// </summary>
    //    private static Dictionary<string, Func<string>> viewMatch = new Dictionary<string, Func<string>>()
    //{
    //    {"MyMenus",() => SystemService.GetUserMenusTreeJSON(SysContext.CurrentUserID)}
    //};
        public string func = "SystemMenu.ashx";
        public string catchError = "main error!";
        public int isShow = 2;//显示所有菜单
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            try
            {
                string view = context.Request["showtype"];
                if (view != string.Empty)
                {
                    isShow = Convert.ToInt32(view);
                }
                string json = "[]";
                //如果视图注册了 视图自定义加载函数
                //if (viewMatch.ContainsKey(view))
                //{
                //    json = viewMatch[view]();
                //}
                //else
                //{
                string user_id = BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
                Whbost.BLL.SystemUser.UserMenuBLL db = new Whbost.BLL.SystemUser.UserMenuBLL();
                json = db.UserMenu_list_json(user_id, isShow);
                // }
                context.Response.Write(json);
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                context.Response.Write(catchError);
            }
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
