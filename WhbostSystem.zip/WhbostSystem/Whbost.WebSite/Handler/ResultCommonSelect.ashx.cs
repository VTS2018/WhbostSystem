﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using Whbost.BLL;
using System.Web.SessionState;

namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/", Description = "处理返回结果为Json格式的系统选择项")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ResultCommonSelect : IHttpHandler, IRequiresSessionState
    {
        public string resultJson = "[]";
        public string ashxFunc = string.Empty;//需要执行的函数块
        public string func = "ResultCommonSelect.ashx"; //执行运算的主函数
        public string catchError = "main error!";
        public void ProcessRequest(HttpContext context)
        {
            string user_id = BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
            try
            {
                context.Response.ContentType = "text/plain";
                ashxFunc = Whbost.Common.systemDefault.ReturnString(context.Request["ashxFunc"]);
                string selectfield = Whbost.Common.systemDefault.ReturnString(context.Request["selectfield"]);
                switch (ashxFunc)
                {
                    case "common":
                        Whbost.BLL.ALL.SysCommonBLL dbselect = new Whbost.BLL.ALL.SysCommonBLL();
                        resultJson = dbselect.Sys_Common_Select_json(selectfield);
                        break;
                }
                context.Response.Write(resultJson);
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                context.Response.Write(catchError);
            }
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
