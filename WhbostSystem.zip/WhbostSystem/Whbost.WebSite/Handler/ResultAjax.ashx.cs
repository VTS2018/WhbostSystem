﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using Whbost.Common.AjaxRequest;
using System.Web.SessionState;
using System.Collections.Specialized;

namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/", Description = "处理返回结果为AjaxResult格式的数据")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ResultAjax : IHttpHandler, IRequiresSessionState
    {

        private AjaxResult ajaxResult = null;
        private string ashxFunc = string.Empty; //需要执行的函数块
        private string func = "SystemMenu.ashx"; //执行运算的主函数
        private bool resultBool = false;
        private string resultMessage = string.Empty;
        private string trueMessage = Whbost.Common.systemDefault.trueMessage;
        private string falseMessage = Whbost.Common.systemDefault.falseMessage;
        NameValueCollection form = new NameValueCollection();
        public void ProcessRequest(HttpContext context)
        {
            string user_id =BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
            try
            {
                context.Response.ContentType = "text/plain";
                form = context.Request.Form;
                ashxFunc = Whbost.Common.systemDefault.ReturnString(context.Request["ashxFunc"]);
                switch (ashxFunc)
                {
                    #region 系统常用分类
                    case "sys_common_category_modify":
                        Whbost.BLL.ALL.SysCommonBLL sys_category_1 = new Whbost.BLL.ALL.SysCommonBLL();
                        resultBool = sys_category_1.Sys_Common_Category_Modify(form);
                        falseMessage = "编辑数据错误，编码已存在!";
                        break;
                    case "sys_common_category_add":
                        Whbost.BLL.ALL.SysCommonBLL sys_category_2 = new Whbost.BLL.ALL.SysCommonBLL();
                        resultBool = sys_category_2.Sys_Common_Category_Add(form);
                        break;
                    case "sys_common_category_selectvalue_add":
                        Whbost.BLL.ALL.SysCommonBLL sys_category_3 = new Whbost.BLL.ALL.SysCommonBLL();
                        resultBool = sys_category_3.Sys_Common_Category_SelectValue_Add(form);
                        break;
                    case "sys_common_category_selectvalue_del":
                        Whbost.BLL.ALL.SysCommonBLL sys_category_4 = new Whbost.BLL.ALL.SysCommonBLL();
                        string category_selectvalue_id = Whbost.Common.systemDefault.ReturnString(context.Request["category_selectvalue_id"]);
                        resultBool = sys_category_4.Sys_Common_Category_SelectVaule_Del(category_selectvalue_id);
                        break;
                    case "sys_common_category_selectvalue_modfiy":
                        Whbost.BLL.ALL.SysCommonBLL sys_category_5 = new Whbost.BLL.ALL.SysCommonBLL();
                        resultBool = sys_category_5.Sys_Common_Category_SelectVaule_Modify(form);
                        break;
                    #endregion

                    #region 用户便捷收藏
                    case "user_favorite_modify":
                        Whbost.BLL.SystemUser.UserFaveriteBLL db = new Whbost.BLL.SystemUser.UserFaveriteBLL();
                        string menuID = Whbost.Common.systemDefault.ReturnString(context.Request["MenuID"]);
                        string favoriteContent = Whbost.Common.systemDefault.ReturnString(context.Request["FavoriteContent"]);
                        string favorite_id = Whbost.Common.systemDefault.ReturnString(context.Request["favorite_id"]);
                        func = "UserFaverite_modify";
                        resultBool = db.UserFaverite_modify(menuID, favoriteContent, favorite_id, user_id);
                        break;
                    #endregion

                    #region 系统菜单操作
                    case "sysmenu_add":
                        Whbost.BLL.SystemUser.UserMenuBLL db1 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        resultBool = db1.Sysmenu_add(form);
                        falseMessage = "菜单编号已存在，请重新取名!";
                        break;
                    case "sysmenu_del":
                        Whbost.BLL.SystemUser.UserMenuBLL db2 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        string menu_id = Whbost.Common.systemDefault.ReturnString(context.Request["menu_id"]);
                        resultBool = db2.Sysmenu_del(menu_id);
                        break;
                    case "sysmenu_modify":
                        Whbost.BLL.SystemUser.UserMenuBLL db3 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        resultBool = db3.Sysmenu_modify(form);
                        falseMessage = "编辑错误:菜单编号已存在，请重新取名!";
                        break;
                    #endregion

                    #region 网站管理
                    case "sitemaster_add":
                        Whbost.BLL.ALL.SiteMasterBLL sitemaster_1 = new Whbost.BLL.ALL.SiteMasterBLL();
                        resultBool = sitemaster_1.SiteMaster_add(form);
                        falseMessage = "模板编号重复!";
                        break;
                    case "sitemaster_modify":
                        Whbost.BLL.ALL.SiteMasterBLL sitemaster_2 = new Whbost.BLL.ALL.SiteMasterBLL();
                        resultBool = sitemaster_2.SiteMaster_modify(form);
                        falseMessage = "模板编号重复!";
                        break;
                    case "sitemaster_del":
                        Whbost.BLL.ALL.SiteMasterBLL sitemaster_3 = new Whbost.BLL.ALL.SiteMasterBLL();
                        string sitemaster_id = Whbost.Common.systemDefault.ReturnString(context.Request["sitemaster_id"]);
                        resultBool = sitemaster_3.SiteMaster_del(sitemaster_id);
                        break;
                    case "sitemaster_img_del":
                        Whbost.BLL.ALL.SiteMasterBLL sitemaster_4 = new Whbost.BLL.ALL.SiteMasterBLL();
                        sitemaster_id = Whbost.Common.systemDefault.ReturnString(context.Request["sitemaster_id"]);
                        string imgValue = Whbost.Common.systemDefault.ReturnString(context.Request["imgValue"]);
                        resultBool = sitemaster_4.SiteMaster_img_del(sitemaster_id, imgValue);
                        falseMessage = "图片删除失败!";
                        break;
                    #endregion

                    #region 上传文件管理
                    case "filedown_del":
                        Whbost.BLL.ALL.FileDownBLL filedown_del_1 = new Whbost.BLL.ALL.FileDownBLL();
                        string file_down_id = Whbost.Common.systemDefault.ReturnString(context.Request["file_down_id"]);
                        resultBool = filedown_del_1.Filedown_del(file_down_id);
                        falseMessage = "删除文件操作失败!";
                        break;
                    #endregion

                }
                //返回结果提示定义
                resultMessage = Whbost.Common.systemDefault.ReturnBoolMessage(resultBool,trueMessage, falseMessage);
                if (resultBool == true)
                    ajaxResult = AjaxResult.Success(resultMessage);
                else
                    ajaxResult = AjaxResult.Error(resultMessage);
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                ajaxResult = AjaxResult.Error(ex.ToString());
            }
            context.Response.Write(ajaxResult);
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
