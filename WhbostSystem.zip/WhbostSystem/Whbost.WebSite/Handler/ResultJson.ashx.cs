﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using Whbost.BLL;
using System.Web.SessionState;

namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/" , Description="处理返回结果为Json格式的数据")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ResultJson : IHttpHandler, IRequiresSessionState
    {
        public string resultJson = "[]";
        public string ashxFunc = string.Empty;//需要执行的函数块
        public string func = "ResultJson.ashx"; //执行运算的主函数
        public string catchError = "main error!";
        public void ProcessRequest(HttpContext context)
        {
            string user_id = BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
            try
            {
                context.Response.ContentType = "text/plain";
                ashxFunc = Whbost.Common.systemDefault.ReturnString(context.Request["ashxFunc"]);
                ///获取GIRD需要的常用参数
                string sortname = Whbost.Common.systemDefault.ReturnString(context.Request["sortname"]);
                string sortorder = Whbost.Common.systemDefault.ReturnString(context.Request["sortorder"]);
                string wherestr = Whbost.Common.systemDefault.ReturnString(context.Request["where"]);
                int _pagenumber = Whbost.Common.systemDefault.ReturnInt(Convert.ToInt32(context.Request["page"]));
                int _pagesize = Whbost.Common.systemDefault.ReturnInt(Convert.ToInt32(context.Request["pagesize"]));
                switch (ashxFunc)
                {
                    #region 用户收藏夹
                    case "user_favorite":
                        Whbost.BLL.SystemUser.UserFaveriteBLL db1=new Whbost.BLL.SystemUser.UserFaveriteBLL();
                        func = "UserFaverite_list_json";
                        resultJson = db1.UserFaverite_list_json(user_id);
                        break;
                    #endregion

                    #region 系统通用操作
                    case "sys_common_category_grid":
                        Whbost.BLL.ALL.SysCommonBLL syscommon_1 = new Whbost.BLL.ALL.SysCommonBLL();
                        func = "Sys_Common_Category_DataGrid";
                        int isValid = Whbost.Common.systemDefault.ReturnInt_default(context.Request["isValid"], 2);
                        resultJson = syscommon_1.Sys_Common_Category_DataGrid(sortname, sortorder, wherestr, _pagenumber, _pagesize, isValid);
                        break;
                    case "sys_common_category_value_grid":
                        Whbost.BLL.ALL.SysCommonBLL syscommon_2 = new Whbost.BLL.ALL.SysCommonBLL();
                        func = "Sys_Common_Category_DataGrid";
                        string category_id = Whbost.Common.systemDefault.ReturnString(context.Request["category_id"]);
                        resultJson = syscommon_2.Sys_Common_Category_SelectValue_DataGrid(sortname, sortorder, wherestr, _pagenumber, _pagesize, category_id);
                        break;
                    case "sys_common_category_one":
                        Whbost.BLL.ALL.SysCommonBLL syscommon_3 = new Whbost.BLL.ALL.SysCommonBLL();
                        func = "Sys_Common_Category_DataGrid";
                        category_id = Whbost.Common.systemDefault.ReturnString(context.Request["category_id"]);
                        resultJson = syscommon_3.Sys_Common_Category_One(category_id);
                        break;
                    case "sys_common_category_selectvalue_one":
                        Whbost.BLL.ALL.SysCommonBLL syscommon_4 = new Whbost.BLL.ALL.SysCommonBLL();
                        func = "Sys_Common_Category_SelectVaule_One";
                        string category_selectvalue_id = Whbost.Common.systemDefault.ReturnString(context.Request["category_selectvalue_id"]);
                        resultJson = syscommon_4.Sys_Common_Category_SelectVaule_One(category_selectvalue_id);
                        break;
                    #endregion 

                    #region 系统菜单
                    case "sys_menu":
                        Whbost.BLL.SystemUser.UserMenuBLL db2 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "UserMenu_list_json";
                        //显示所有可以编辑菜单
                        resultJson = db2.UserMenu_list_json(user_id, 2);
                        break;
                    case "sys_menu_grid":
                        Whbost.BLL.SystemUser.UserMenuBLL db3 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "UserMenu_list_json_grid";
                        //显示所有可以编辑菜单
                        resultJson = db3.UserMenu_list_json_grid(user_id, 2, _pagenumber,_pagesize);
                        break;
                    case "sys_menu_next_grid":
                        Whbost.BLL.SystemUser.UserMenuBLL db3_1 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "UserMenu_next_list_json_grid";
                        //显示所有可以编辑菜单
                        string menu_no = Whbost.Common.systemDefault.ReturnString(context.Request["menu_no"]);
                        if (menu_no!=null&&menu_no != string.Empty)
                        {
                            resultJson = db3_1.UserMenu_next_list_json_grid(user_id, _pagenumber, _pagesize, menu_no);
                        }
                        break;
                   
                    case "sys_menu_one":
                        string menu_id = Whbost.Common.systemDefault.ReturnString(context.Request["menu_id"]);
                        Whbost.BLL.SystemUser.UserMenuBLL db5 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "Sysmenu_json_one";
                        //显示所有可以编辑菜单
                        resultJson = db5.Sysmenu_json_one(menu_id);
                        break;
                    case "sys_menu_one_bymenu_no_select":
                         menu_no = Whbost.Common.systemDefault.ReturnString(context.Request["menu_no"]);
                        Whbost.BLL.SystemUser.UserMenuBLL db6 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "sys_menu_one_bymenu_no_select";
                        //显示所有可以编辑菜单
                        resultJson = db6.sys_menu_one_bymenu_no_select(menu_no);
                        break;
                    #endregion

                    #region 系统按钮
                    case "sys_menu_btn":
                        menu_no = Whbost.Common.systemDefault.ReturnString(context.Request["menu_no"]);
                        Whbost.BLL.SystemUser.UserMenuBLL db4 = new Whbost.BLL.SystemUser.UserMenuBLL();
                        func = "sys_menu_btn";
                        //显示所有可以编辑菜单
                        resultJson = db4.UserBtn_json(user_id, menu_no);
                        break;
                    #endregion

                    #region 网站管理
                    case "site_master_grid":
                        Whbost.BLL.ALL.SiteMasterBLL db_site_1 = new Whbost.BLL.ALL.SiteMasterBLL();
                        func = "UserMenu_list_json_grid";
                        //显示所有可以编辑菜单
                        resultJson = db_site_1.SiteMaster_Json_DataGrid(sortname, sortorder, wherestr, _pagenumber, _pagesize);
                        break;
                    case "site_master_view":
                        Whbost.BLL.ALL.SiteMasterBLL db_site_2 = new Whbost.BLL.ALL.SiteMasterBLL();
                        string sitemaster_id = Whbost.Common.systemDefault.ReturnString(context.Request["sitemaster_id"]);
                        func = "site_master_view";
                        //显示所有可以编辑菜单
                        resultJson = db_site_2.SiteMaster_view(sitemaster_id);
                        break;
                    #endregion

                    #region select源数据
                    case "sl_sys_menu":
                        Whbost.BLL.SystemUser.UserMenuBLL dbselect = new Whbost.BLL.SystemUser.UserMenuBLL();
                        resultJson = dbselect.UserMenu_list_json_select(user_id, 3);
                        break;
                    #endregion

                    #region 文件上传处理
                    case "filedown_list":
                        string file_id = Whbost.Common.systemDefault.ReturnString(context.Request["file_id"]);
                        Whbost.BLL.ALL.FileDownBLL filedown_list_1 = new Whbost.BLL.ALL.FileDownBLL();
                        resultJson = filedown_list_1.Filedown_list(file_id);
                        break;
                    #endregion 

                    #region SEO-LINKS外链操作
                    case "seo_links_grid":
                        Whbost.BLL.ALL.SEOBLL seo_1 = new Whbost.BLL.ALL.SEOBLL();
                       // string sitemaster_id = Whbost.Common.systemDefault.ReturnString(context.Request["sitemaster_id"]);
                        func = "SEO_Links_Json_DataGird";
                        //显示所有可以编辑菜单
                        resultJson = seo_1.SEO_Links_Json_DataGird(sortname, sortorder, wherestr, _pagenumber, _pagesize);
                        break;
                    #endregion
                }
                context.Response.Write(resultJson);
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                context.Response.Write(catchError);
            }
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
