﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using Whbost.Common.AjaxRequest;
using System.Web.SessionState;


namespace Whbost.WebSite.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class Validate : IHttpHandler, IRequiresSessionState
    {
        public string func = "Validate.ashx";
        public string catchError = "main error!";
        public void ProcessRequest(HttpContext context)
        {

            context.Response.ContentType = "text/plain";
            try
            {
                if (context.Request.Params["Action"] == "Exist")
                    func = "ValidateExist";
                    ValidateExist();
                    if (context.Request.Params["Action"] == "Login")
                        func = "ValidateLogin";
                    ValidateLogin();
            }
            catch (Exception ex)
            {
                Whbost.Common.systemDefault.WriteError(func, ex.ToString());
                context.Response.Write(catchError);
            }
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        void ValidateExist()
        {
 
        }
        void ValidateLogin()
        {
            var context = System.Web.HttpContext.Current;
            string username = context.Request.Params["username"];
            string password = context.Request.Params["password"];
            Whbost.BLL.SystemUser.UserBLL db = new Whbost.BLL.SystemUser.UserBLL();
            AjaxResult userLogin = db.User_login(Whbost.Common.systemDefault.StringTrans(username), Whbost.Common.systemDefault.StringTrans(password));
            if (userLogin != null && userLogin.IsError == false)
            {
                //登录成功，用SESSION存储用户名信息
                context.Session["user_name"] = username;
                string user_id = db.User_Back_userid(username);
                context.Session["user_id"] = user_id;
            }
            context.Response.Write(userLogin);
           
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
