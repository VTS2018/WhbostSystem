﻿using System;
using System.Web;
namespace Whbost.WebSite.BLL
{
    public class BasePagePower : System.Web.UI.Page
    {
        #region 初始化 在Page_Load之间执行
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            //验证是否已经登陆
            if (Whbost.WebSite.BLL.SystemCommonDefault.Session_Check_User()==false)
            {
                Response.Redirect("/");
            }
            //如果已经登陆了，加载登陆人员的信息，
            //这里使用数组，您也可以使用其他的您习惯的方式。

            //加载代码略

            //清除IE缓存
            Response.Cache.SetNoStore();
        }
        #endregion
    }
}
