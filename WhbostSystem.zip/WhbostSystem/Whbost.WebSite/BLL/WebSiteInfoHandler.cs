﻿using System;
using System.Configuration;
using System.Collections.Specialized;

namespace ConfigurationSectionTest
{
    /// <summary>
    ///WebSiteInfoHandler 的摘要说明
    /// </summary>
    public class WebSiteInfoHandler : IConfigurationSectionHandler
    {
        public WebSiteInfoHandler()
        {
            //
            //TODO: 在此处添加构造函数逻辑
            //

        }

        #region IConfigurationSectionHandler 成员

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            //这里我们首先返回个hello，并且在此处设置一个断点。看看程序什么时候执行到这。
            NameValueCollection configs;
            NameValueSectionHandler baseHandler = new NameValueSectionHandler();
            configs = (NameValueCollection)baseHandler.Create(parent, configContext, section);
            return configs;
        }

        #endregion
    }

}
