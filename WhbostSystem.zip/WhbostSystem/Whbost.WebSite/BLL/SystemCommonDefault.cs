﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace Whbost.WebSite.BLL
{
    public class SystemCommonDefault
    {
        #region 获取全局的Application对象
        public static string Static_System_Name()
        {
            return System.Web.HttpContext.Current.Application["systemName"].ToString();
        }
        public static string Static_System_CopyRight()
        {
            return System.Web.HttpContext.Current.Application["copyRight"].ToString();
        }
        #endregion

        #region 获取会话对象
        public static string Session_User_ID()
        {
            return System.Web.HttpContext.Current.Session["user_id"] != null ? Whbost.Common.systemDefault.ReturnString(System.Web.HttpContext.Current.Session["user_id"].ToString()) : string.Empty;
        }
        public static string Session_User_Name()
        {
            return System.Web.HttpContext.Current.Session["user_name"] != null ? Whbost.Common.systemDefault.ReturnString(System.Web.HttpContext.Current.Session["user_name"].ToString()) : string.Empty;
        }
        public static bool Session_Check_User()
        {
            if (Session_User_Name() != string.Empty && Session_User_ID() != string.Empty)
                return true;
            else
                return false;
        }
        #endregion

        #region 生成常用的隐藏控件
        public static string Hidden_tabName()
        {
            string hiddenHTML = string.Empty;
            if (HttpContext.Current.Request["tabid"] != null)
            {
                hiddenHTML += Whbost.Common.systemDefault.ReturnHiddenHTML("tabid", Whbost.Common.systemDefault.ReturnString_normal(HttpContext.Current.Request["tabid"]));
            }
            if (HttpContext.Current.Request["ftabid"] != null)
            {
                hiddenHTML += Whbost.Common.systemDefault.ReturnHiddenHTML("ftabid", Whbost.Common.systemDefault.ReturnString_normal(HttpContext.Current.Request["ftabid"]));
            }
            hiddenHTML += Hidden_view();
            return hiddenHTML;
        }
        public static string Hidden_view()
        {
            string hiddenHTML = string.Empty;
            string viewValue = "0";
            if (HttpContext.Current.Request["view"] != null)
            {
                viewValue = "1";
            }
            hiddenHTML = Whbost.Common.systemDefault.ReturnHiddenHTML("hd_view", viewValue);
            return hiddenHTML;
        }
        #endregion

    }
}
