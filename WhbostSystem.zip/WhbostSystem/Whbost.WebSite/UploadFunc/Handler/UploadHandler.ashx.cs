﻿using System;
using System.Collections;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.IO;
using System.Web.SessionState;
using System.Collections.Specialized;

namespace Whbost.WebSite.UploadFunc.Handler
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://www.whbost.com")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class UploadHandler : IHttpHandler, IRequiresSessionState
    {
        
        NameValueCollection form = new NameValueCollection();
        public void ProcessRequest(HttpContext context)
        {
            ////////////开始进行相应的上传权限验证///////////////////////////////////////////
            string user_id = BLL.SystemCommonDefault.Session_User_ID();//获取用户user_id
            ////////////////////////////////////////
            context.Response.ContentType = "text/plain";
            string backMessage="1";
            string newFileName = string.Empty;
            string filePath = string.Empty;
            string ajaxFunc = string.Empty;
            string paramID = string.Empty;
            form = context.Request.Form;
            ajaxFunc = Whbost.Common.systemDefault.ReturnString(context.Request["ajaxFunc"]);
            //获取传递的ID,并以次ID建立新的文件夹
            paramID = Whbost.Common.systemDefault.ReturnString(context.Request["paramID"]);
            //组成新的文件夹
            filePath = paramID;
            HttpPostedFile file = context.Request.Files["FileData"];
            string uploadpath = HttpContext.Current.Server.MapPath(context.Request["folder"] + "\\");
            uploadpath += (filePath != string.Empty ? ("\\" + filePath+"\\") : string.Empty);
            if (file != null)
            {
                if (!Directory.Exists(uploadpath))
                {
                    Directory.CreateDirectory(uploadpath);
                }
                string fileName = file.FileName;
                 //检查图片是否存在
                string picPath = uploadpath + "\\" + fileName;
                if (File.Exists(picPath))
                {
                   //图片存在就进行重新的命名
                    newFileName = Whbost.Common.systemDefault.GenerateRandom() + "." + fileName.Substring(fileName.LastIndexOf(".")+1);
                }
                fileName = (newFileName != string.Empty ? newFileName : fileName);
                ///****************开始保存图片***********************
                //1.保存原图
                string oPath=uploadpath + fileName;
                file.SaveAs(oPath);
                //2.保存大图
                string bWidth = Whbost.Common.systemDefault.ReturnString(context.Request["b"]);
                if (Whbost.Common.systemDefault.ReturnInt(bWidth) > 0)
                {
                    string bPath = uploadpath + fileName.Substring(0,fileName.LastIndexOf(".")) + "_b" + "." + fileName.Substring(fileName.LastIndexOf(".") + 1);
                    Whbost.Common.systemDefault.MakeThumbnail(oPath, bPath, Whbost.Common.systemDefault.ReturnInt(bWidth), 0, "W");
                }
                //2.保存中图
                string mWidth = Whbost.Common.systemDefault.ReturnString(context.Request["m"]);
                if (Whbost.Common.systemDefault.ReturnInt(mWidth) > 0)
                {
                    string mPath = uploadpath + fileName.Substring(0, fileName.LastIndexOf(".")) + "_m" + "." + fileName.Substring(fileName.LastIndexOf(".") + 1);
                    Whbost.Common.systemDefault.MakeThumbnail(oPath, mPath, Whbost.Common.systemDefault.ReturnInt(mWidth), 0, "W");
                }
                //2.保存小图
                string sWidth = Whbost.Common.systemDefault.ReturnString(context.Request["s"]);
                if (Whbost.Common.systemDefault.ReturnInt(sWidth) > 0)
                {
                    string sPath = uploadpath + fileName.Substring(0, fileName.LastIndexOf(".")) + "_s" + "." + fileName.Substring(fileName.LastIndexOf(".") + 1);
                    Whbost.Common.systemDefault.MakeThumbnail(oPath, sPath, Whbost.Common.systemDefault.ReturnInt(sWidth), 0, "W");
                }
                ///****************保存图片结束***********************
              //开始执行保存数据库操作
                Whbost.BLL.ALL.SiteMasterBLL db = new Whbost.BLL.ALL.SiteMasterBLL();
                switch (ajaxFunc)
                {
                    case "site"://添加模板图片
                        if (!db.SiteMaster_img_add(paramID, fileName))
                            backMessage = "0";
                        break;
                    case "site_file"://添加模板文件
                        string filedesc = Whbost.Common.systemDefault.ReturnString_normal(context.Request["filedesc"]);
                        paramID = Whbost.Common.systemDefault.ReturnString_normal(context.Request["paramID"]);
                        Whbost.BLL.ALL.FileDownBLL site_file_1 = new Whbost.BLL.ALL.FileDownBLL();
                        if (!site_file_1.Filedown_add(filedesc, fileName, "UploadFileFolder/SiteMaster", user_id, paramID))
                            backMessage = "0";
                        break;
                }
                context.Response.Write(backMessage);
            }
            else
            {
                context.Response.Write("0");
            }
            context.Response.End();
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
