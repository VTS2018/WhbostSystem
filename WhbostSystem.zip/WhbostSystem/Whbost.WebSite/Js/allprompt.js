﻿//基于 lib 的脚本框架，正确使用前，先引用lib的脚本文件
//实例二：$.ligerDialog.success('提示内容') 
//实例三：$.ligerDialog.warn('提示内容') 
//实例四：$.ligerDialog.error('提示内容')
//实例五：$.ligerDialog.question('提示内容')
//实例六：$.ligerDialog.confirm('提示内容', function (yes) { alert(yes); });
//实例七：$.ligerDialog.warning('提示内容', function (type) { alert(type); });
//实例八：$.ligerDialog.prompt('提示内容', function (yes,value) { if(yes) alert(value); });
//实例九：$.ligerDialog.prompt('提示内容','初始化值', function (yes,value) { if(yes) alert(value); });
//实例十：$.ligerDialog.prompt('提示内容',true, function (yes,value) { if(yes) alert(value); });
//实例十一：$.ligerDialog.prompt('提示内容','初始化多选框值',true, function (yes,value) { if(yes) alert(value); });
//实例十二：$.ligerDialog.waitting('正在保存中,请稍候...'); setTimeout(function () { $.ligerDialog.closeWaitting(); }, 2000);
//实例十二：var manager = $.ligerDialog.waitting('正在保存中2,请稍候...'); setTimeout(function () { manager.close(); }, 1000);
var Z_alert=
{
    nodata:"<div class='div_nodata'>暂时没有数据，请添加数据!</div>",
    warn:function(ntype)
    {
        var alertMessage="";
        switch(ntype)
        {
            case "account":
            alertMessage="账号不能为空！";
            break;
            case "pwd":
            alertMessage="密码不能为空！";
            break;
            case "cookie":
            alertMessage="对不起，您的浏览器的Cookie功能被禁用，为保证系统正常使用，请开启！";
            case "nomenu":
            alertMessage="对不起，该用户还没有系统菜单权限，请联系管理员！";
            break;
            case "nodata":
            alertMessage="暂时无数据，请进行数据添加!";
        }
        $.ligerDialog.warn(alertMessage);
    },
    error:function(ntype)
    {
        var alertMessage="";
        switch(ntype)
        {
            case "system":
            alertMessage="系统出现错误，请尝试再次操作!";
            break;
            case "login":
            alertMessage="登陆失败，账号或密码有误！";
            break;
            case "login_system":
            alertMessage="登陆发生系统错误，请与系统管理员联系！";
            break;
            default:
            alertMessage="数据操作失败，请尝试再次操作!";
            break;
            
        }
        $.ligerDialog.error(alertMessage);
    },
    succ:function(ntype)
    {
        var alertMessage="";
        switch(ntype)
        {
            case "login":
            alertMessage="登陆失败，账号或密码有误！";
            break;
        }
        $.ligerDialog.success(alertMessage);
    }
}
var Z_ashx=
{
    ajax:"/Handler/ResultAjax.ashx",
    json:"/Handler/ResultJson.ashx",
    select:"/Handler/ResultCommonSelect.ashx",
    data:"/Handler/ResultData.ashx",
    login:"/Handler/Validate.ashx",
    sysmenu:"/Handler/SystemMenu.ashx",
    upload:"/UploadFunc/Handler/UploadHandler.ashx",
    fname:"ashxFunc"
}
var Z_tab=
{
   tabid:"",
   ftabid:""
}
function  Z_func_tab()
{
    Z_tab.tabid=($("#tabid").length>0?$("#tabid").val():"");
    Z_tab.ftabid=($("#ftabid").length>0?$("#ftabid").val():"");
}
var Z_picurl=
{
    nosite:"/Images/nosite.jpg",
    site:"/UploadFile/SiteMaster/"
}
function Z_func_pic(folderID,imgList,imgtype,imgwidth)
{
    var imgwidth_default="150";
    if(imgwidth!=null){imgwidth_default=imgwidth;}
    var backImg="<img src='"+Z_picurl.nosite+"' style='width:"+imgwidth_default+"px;height:auto' />";
    if(imgList!=null&&imgList!="")
    {
        var imgArr=imgList.split('|');
        if(imgArr.length>0)
        {
            var imgName=imgArr[0];
            var img0=imgName.substring(0,imgName.lastIndexOf("."));
            var img1=imgName.substring(imgName.lastIndexOf("."));
            var newPath=Z_picurl.site+folderID+"/"+imgArr[0];
            var oPath=newPath;
            if(imgtype=="b"){newPath=Z_picurl.site+folderID+"/"+img0+"_b"+img1;}
            if(imgtype=="m"){newPath=Z_picurl.site+folderID+"/"+img0+"_m"+img1;}
            if(imgtype=="s"){newPath=Z_picurl.site+folderID+"/"+img0+"_s"+img1;}
            backImg="<div class='div_img_1'><img src='"+newPath+"' style='width:"+imgwidth_default+"px;height:auto;cursor:pointer' onclick=\"z_func_bigimg(\'"+oPath+"\')\" /></div>";
        }
    }
    return backImg;
}
function Z_func_site_piclist(folderID,imgarr)
{
    if(imgarr=="")
        return "";
    var arr=imgarr.split('|');
    var imghtml="";
    var picPath="/UploadFile/SiteMaster/";
    picPath+=folderID+"/";
    imghtml+="<ul id=\"zul_site\">\n";
    for(var i=0;i<arr.length;i++)
    {
        if(arr[i]=="") break;
        var newPicPath=picPath+arr[i];
        imghtml+="<li><p>("+(i+1)+")"+arr[i]+"</p><div><img src=\""+newPicPath+"\"  onclick=\"z_func_bigimg(\'"+newPicPath+"\')\" /></div><p style=\"text-align:right\"><img src=\"/lib/icons/silkicons/cancel.png\" onclick=\"Z_func_site_delImg(\'"+arr[i]+"\')\" style=\"width:18px;\" alt=\"删除\" title=\"删除\" /></p></li>\n";
    }
    imghtml+="</ul>\n";
    return imghtml;
}
//自定义的文件AJAX函数部分
var Z_ajax=
{
    z_file_id:"", 
    z_divname:"",
    filedown_list:function(file_id,divname)
    {
         Z_ajax.z_file_id=file_id;
         Z_ajax.z_divname=divname;
        $("#"+divname+"").ligerGrid({
          columns:[
                { display: '文件名', name: 'file_desc',  width: 170, minWidth: 60},
                { display: '操作', isSort: false, width: 60, render: function (rowdata, rowindex, value)
                    {
                        var h = "";
                    var h = "";
                         h += "<a href=\"javascript:void(null)\" onclick=\"Z_ajax.filedown_del(\'"+rowdata.file_down_id+"\')\"><img src=\"/lib/icons/silkicons/cancel.png\" /></a> ";
                         h += "<a href=\"javascript:void(null)\" onclick=\"Z_ajax.filedown_down(\'"+rowdata.file_down_id+"\')\"><img src=\"/lib/icons/silkicons/arrow_down.png\" /></a> "; 
                        return h;
                    }
                }
            ],
          usePager: false,// false表示不出现翻页
          dataAction: 'server',
          url: Z_ashx.json+"?"+Z_ashx.fname+"=filedown_list"+"&file_id="+file_id, 
          rownumbers:true,
          width: '99%', height: '90%', checkbox: false
      });
    },
    filedown_del:function(file_down_id)
    {
      jQuery.ligerDialog.confirm("确定删除该文件吗?", function (confirm) {
      if (confirm)
         {
                LG.ajax({
                load:"开始删除文件...",
                url: Z_ashx.ajax,
                data: [
                { name: Z_ashx.fname, value: 'filedown_del' },
                { name: 'file_down_id', value: file_down_id }
                ],
                success: function (result)
                {
                    if(result.IsError==true)
                        $.ligerDialog.error(result.Message)
                    else
                        Z_ajax.filedown_list(Z_ajax.z_file_id,Z_ajax.z_divname);
                }
            });
         }});
    },
    filedown_down:function(file_down_id)
    {},
    select:function(field,slname,text,show)
    {
         LG.ajax({
                load:"开始加载Select数据",
                url: Z_ashx.data+"?rnd="+Math.random(),
                data: [
                { name: Z_ashx.fname, value: 'select' },
                { name: 'selectfield', value: field },
                { name: 'selectname', value: slname },
                { name: 'defaulttext', value: text }
                ],
                success: function (result)
                {
                   $("#"+show+"").html(result.Message);
                }
            });
    },
    select_z:function(showlable,slname,showname,valuelist,text)
    {
        var showAll="所有数据";
        if(text!=null||text!=""){ showAll=text;}
        var selectHTML = "<select id=\"" + slname + "\">\n";
        selectHTML += "<option value=\"\">" + showAll + "</option>\n";
        for(var i=0;i<valuelist.length;i++)
        {
            var arr=valuelist[i].split('|');
            selectHTML += "<option value=\""+arr[0]+"\">" + arr[1] + "</option>\n";
        }
        selectHTML+="</select>\n";
        document.getElementById(showname).innerHTML+=("<font style=\"padding:3px;8px\">"+showlable + " : " +"</font>"+ selectHTML);
    },
    combobox:function(txtNmae,selectfield,initText)
    {
           $("#"+txtNmae+"").ligerComboBox({
              url:Z_ashx.select+"?"+Z_ashx.fname+"=common"+"&selectfield="+selectfield, 
              isMultiSelect: false,
              initText:initText
            });
    }
}
//显示单张大图
function z_func_bigimg(imgurl)
{
    var win1;
       var imgShow="<a href=\""+imgurl+"\" target='_blank'><img src=\""+imgurl+"\" style=\"height:450px\" /></a>";
       win1=$.ligerDialog.open({width: null,height:null,modal:false,content:imgShow});
       win1.mask();
}