﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace Whbost.WebSite.Admin.SystemMenu
{
    public partial class ModifyNextMenu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //if (Request["parentMenuNo"] != null)
                //{
                //    lt_hidden.Text += Whbost.Common.systemDefault.ReturnHiddenHTML("parentMenuNo", Whbost.Common.systemDefault.ReturnString(Request["parentMenuNo"]));
                //}
                if (Request["menu_id"] != null)
                {
                    lt_hidden.Text = Whbost.Common.systemDefault.ReturnHiddenHTML("menu_id", Whbost.Common.systemDefault.ReturnString(Request["menu_id"]));
                }
                  if (Request["menu_parent_no"] != null)
                {
                    lt_hidden.Text = Whbost.Common.systemDefault.ReturnHiddenHTML("hd_menu_parent_no", Whbost.Common.systemDefault.ReturnString(Request["menu_parent_no"]));
                }
                //string viewValue = "0";
                //if (Request["view"] != null)
                //{
                //    viewValue = "1";
                //}
                //lt_hidden.Text += Whbost.Common.systemDefault.ReturnHiddenHTML("hd_view", viewValue);
            }
        }
    }
}
