﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace Whbost.WebSite.Admin
{
    public partial class Welcome1 : BLL.BasePagePower
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Whbost.WebSite.BLL.SystemCommonDefault.Session_Check_User()==true)
                {
                    if (Whbost.WebSite.BLL.SystemCommonDefault.Session_User_ID() == "8888888888")
                    {
                        string linkUrl = Whbost.Common.systemDefault.ReturnString(Application["InitMenu_url"]) + "?MenuNo=" + Whbost.Common.systemDefault.ReturnString_normal(Application["InitMenu_no"].ToString()) + "&tabid=tabid_" + Whbost.Common.systemDefault.ReturnString_normal(Application["InitMenu_no"].ToString());
                        lt_menu.Text = "<a href=\"#\" onclick=\"top.f_addTab('tabid_" + Whbost.Common.systemDefault.ReturnString_normal(Application["InitMenu_no"].ToString()) + "', '" + Whbost.Common.systemDefault.ReturnString(Application["InitMenu_name"]) + "', '" + linkUrl + "')\" style=\"color:#880000;margin:5px\">进入<b>菜单管理</b></a>";
                    }
                }
                else
                {
                    Response.Write("<script>top.window.location= '/'; </script>");
                }
            }
        }
    }
}
