﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace Whbost.WebSite.Admin.SEO
{
    public partial class ModifyLink : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request["link_id"] != null)
                {
                    lt_hidden.Text += Whbost.Common.systemDefault.ReturnHiddenHTML("hd_link_id", Whbost.Common.systemDefault.ReturnString(Request["link_id"]));
                }
            }
        }
    }
}
